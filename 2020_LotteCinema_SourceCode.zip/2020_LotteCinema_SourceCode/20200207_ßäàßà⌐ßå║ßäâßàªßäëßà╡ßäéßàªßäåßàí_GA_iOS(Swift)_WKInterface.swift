func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage){
        if(message.name == "gascriptCallbackHandler"){
            var Thread_Screen = NSMutableDictionary.init()
            let data = (message.body as AnyObject).data(using: String.Encoding.utf8.rawValue,allowLossyConversion: false)!
            do {
                let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String: AnyObject]
                let sType:String
                sType = json["type"] as! String
                if(json["title"] != nil){
                    Thread_Screen.setValue(json["title"] as! String, forKey: "cd")}
                if(json["userId"] != nil) {
                    Thread_Screen.setValue(json["userId"] as! String, forKey: "uid")
                }
                if(json["dimension"] != nil){
                    var dimension = Dictionary<String,AnyObject>()
                    dimension = json["dimension"] as! [String : AnyObject]
                    if dimension != nil{
                        for (key,value) in dimension{
                            let regex = try? NSRegularExpression(pattern: "[^0-9]", options: .caseInsensitive)
                            let textToNS = key as NSString
                            let chidx = regex?.stringByReplacingMatches(in: key, options: [], range: NSRange(location: 0, length: textToNS.length), withTemplate: "")
                            let  idx = (chidx! as NSString)
                            Thread_Screen.setValue(value, forKey: "cd" + (idx as String))
                        }
                    }
                }
                if(json["metric"] != nil){
                    var metric = Dictionary<String, AnyObject>()
                    metric = json["metric"] as! [String : AnyObject]
                    if metric != nil{
                        for (key,value) in metric{
                            var value = value
                            let regex = try? NSRegularExpression(pattern: "[^0-9]", options: .caseInsensitive)
                            let textToNS = key as NSString
                            let chidx = regex?.stringByReplacingMatches(in: key, options: [], range: NSRange(location: 0, length: textToNS.length), withTemplate: "")
                            let  idx = (chidx as! NSString)
                            value = String(value as! Int) as AnyObject
                            Thread_Screen.setValue(value, forKey: "cm" + (idx as String))
                        }
                    }
                }
                if(sType.lowercased().contains("p")){
                    GADataSend_Screen(GAInfo: Thread_Screen as! Dictionary<String, String>)
                } else {
                    if(json["ecommerce"] == nil){
                        if(json["category"] != nil ){
                            Thread_Screen.setValue(json["category"] as! String, forKey: "ec")
                        }
                        if(json["action"] != nil ){
                            Thread_Screen.setValue(json["action"] as! String, forKey: "ea")
                        }
                        if(json["label"] != nil ){
                            Thread_Screen.setValue(json["label"] as! String, forKey: "el")
                        }
                        GADataSend_Event(GAInfo: Thread_Screen as! Dictionary<String, String>)
                    }
                    else{
                        var product_dict = Array<Dictionary<String,AnyObject>>()
                        var productList:String
                        var Ecommerce_step:String
                        let ecommerce_data = json["ecommerce"] as! [String: AnyObject]
                        var ecommerce_sub_data:[String: AnyObject] = [:]

                        for(key, value) in ecommerce_data {
                            Ecommerce_step = key
                            productList = ""
                            if key.lowercased().contains("currencycode"){ Thread_Screen.setValue(json["currencyCode"] as? String, forKey: "cu") }
                            else {
                                ecommerce_sub_data = ecommerce_data[key] as! [String:AnyObject]
                                for (key,value) in ecommerce_sub_data{
                                    if key.lowercased().contains("products"){

                                        product_dict = ecommerce_sub_data[key] as! Array<Dictionary<String,AnyObject>>
                                        Thread_Screen = GAData_Products(product_dict: product_dict, ecommerceBuilder: Thread_Screen)
                                    }
                                    if key.lowercased().contains("actionfield"){
                                        var actionfield_dict:[String:AnyObject] = [:]
                                        actionfield_dict = ecommerce_sub_data[key] as! [String:AnyObject]
                                        Thread_Screen = GAData_Actionfield(actionField_dict: actionfield_dict, productAction: Thread_Screen)
                                    }
                                }
                            }
                            if key.lowercased().contains("detail"){
                                Thread_Screen.setValue("detail", forKey: "pa")
                            }
                            if key.lowercased().contains("click"){
                                Thread_Screen.setValue("click", forKey: "pa")
                            }
                            if key.lowercased().contains("add"){
                                Thread_Screen.setValue("add", forKey: "pa")
                            }

                            if key.lowercased().contains("checkout"){
                                Thread_Screen.setValue("checkout", forKey: "pa")
                            }

                            if key.lowercased().contains("purchase"){
                                Thread_Screen.setValue("purchase", forKey: "pa")
                            }

                            if key.lowercased().contains("remove"){
                                Thread_Screen.setValue("remove", forKey: "pa")
                            }
                            if key.lowercased().contains("refund"){
                                Thread_Screen.setValue("refund", forKey: "pa")
                            }
                            if(json["category"] != nil ){
                                Thread_Screen.setValue(json["category"] as! String, forKey: "ec")
                            }
                            if(json["action"] != nil ){
                                Thread_Screen.setValue(json["action"] as! String, forKey: "ea")
                            }
                            if(json["label"] != nil ){
                                Thread_Screen.setValue(json["label"] as! String, forKey: "el")
                            }

                        }
                        Thread_Screen.setValue("event", forKey: "t")
                        gaThread(dict: Thread_Screen as! Dictionary<String, String>)
                    }
                }
            } catch let error as NSError {
                print("Failed to load: \(error.localizedDescription)")
            }
        }
    }


func GAData_Actionfield(actionField_dict:Dictionary<String,AnyObject>, productAction:NSMutableDictionary) -> NSMutableDictionary{
    do {
        for (key, value) in actionField_dict{
            if key.lowercased().contains("id"){
                productAction.setValue(value as? String, forKey: "ti") }
            if key.lowercased().contains("revenue"){
                productAction.setValue(value as? String, forKey: "tr")}
            if key.lowercased().contains("tax"){
                productAction.setValue(value as? String, forKey: "tt")}
            if key.lowercased().contains("shipping"){
                productAction.setValue(value as? String, forKey: "ts")}
            if key.lowercased().contains("coupon"){
                productAction.setValue(value as? String, forKey: "tcc")}
            if key.lowercased().contains("affiliation"){
                productAction.setValue(value as? String, forKey: "ta")}
            if key.lowercased().contains("list"){
                productAction.setValue(value as? String, forKey: "pal")}
            if key.lowercased().contains("step"){
                productAction.setValue(value as? String, forKey: "cos")}
            if key.lowercased().contains("option"){
                productAction.setValue(value as? String, forKey: "col")}
        }
    }
    catch {
        print("Got an error: \(error)")
    }
    return productAction
    }

func GAData_Products(product_dict:Array<Dictionary<String,AnyObject>>, ecommerceBuilder:NSMutableDictionary) -> NSMutableDictionary{
    do {
        var productDict = NSMutableDictionary()

        for i in 0..<product_dict.count{
            var dict = product_dict[i]
            for(key,value) in dict{
                if key.lowercased().contains("id"){
                    ecommerceBuilder.setValue(value, forKey: "pr" + String(i+1) + "id") }
                if key.lowercased().contains("name"){
                    ecommerceBuilder.setValue(value, forKey: "pr" + String(i+1) + "nm")}
                if key.lowercased().contains("brand"){
                    ecommerceBuilder.setValue(value, forKey: "pr" + String(i+1) + "br")}
                if key.lowercased().contains("category"){
                    ecommerceBuilder.setValue(value, forKey: "pr" + String(i+1) + "ca")}
                if key.lowercased().contains("price"){
                    ecommerceBuilder.setValue(value, forKey: "pr" + String(i+1) + "pr")}
                if key.lowercased().contains("quantity"){
                    ecommerceBuilder.setValue(value, forKey: "pr" + String(i+1) + "qt")}
                if key.lowercased().contains("variant"){
                    ecommerceBuilder.setValue(value, forKey: "pr" + String(i+1) + "va")}
                if key.lowercased().contains("coupon"){
                    ecommerceBuilder.setValue(value, forKey: "pr" + String(i+1) + "cc")}
                if key.lowercased().contains("dimension"){
                    let regex = try? NSRegularExpression(pattern: "[^0-9]", options: .caseInsensitive)
                    let textToNS = key as NSString
                    let chidx = regex?.stringByReplacingMatches(in: key, options: [], range: NSRange(location: 0, length: textToNS.length), withTemplate: "")
                    let  idx = (chidx! as NSString)
                    ecommerceBuilder.setValue(value, forKey: "pr" + String(i+1) + "cd" + (idx as String))
                }
                if key.lowercased().contains("metric"){
                    let regex = try? NSRegularExpression(pattern: "[^0-9]", options: .caseInsensitive)
                    let textToNS = key as NSString
                    let chidx = regex?.stringByReplacingMatches(in: key, options: [], range: NSRange(location: 0, length: textToNS.length), withTemplate: "")
                    let  idx = (chidx! as NSString)

                    ecommerceBuilder.setValue(String(value as! Int) as AnyObject, forKey: "pr" + String(i+1) + "cm" + (idx as String))
                }
            }
        }
    } catch {
        print("Got an error: \(error)")
    }
    return ecommerceBuilder
  }
