import Foundation

enum GACustomKey :CustomStringConvertible{
    case Dimension1; case Dimension2; case Dimension3; case Dimension4; case Dimension5;
    case Dimension6; case Dimension7; case Dimension8; case Dimension9; case Dimension10;
    case Dimension11; case Dimension12; case Dimension13; case Dimension14; case Dimension15;
    case Dimension16; case Dimension17; case Dimension18; case Dimension19; case Dimension20;
    case Dimension21; case Dimension22; case Dimension23; case Dimension24; case Dimension25;
    case Dimension26; case Dimension27; case Dimension28; case Dimension29; case Dimension30;
    case Dimension31; case Dimension32; case Dimension33; case Dimension34; case Dimension35;
    case Dimension36; case Dimension37; case Dimension38; case Dimension39; case Dimension40;
    case Dimension41; case Dimension42; case Dimension43; case Dimension44; case Dimension45;
    case Dimension46; case Dimension47; case Dimension48; case Dimension49; case Dimension50;
    case Dimension51; case Dimension52; case Dimension53; case Dimension54; case Dimension55;
    case Dimension56; case Dimension57; case Dimension58; case Dimension59; case Dimension60;
    case Dimension61; case Dimension62; case Dimension63; case Dimension64; case Dimension65;
    case Dimension66; case Dimension67; case Dimension68; case Dimension69; case Dimension70;
    case Dimension71; case Dimension72; case Dimension73; case Dimension74; case Dimension75;
    case Dimension76; case Dimension77; case Dimension78; case Dimension79; case Dimension80;
    case Dimension81; case Dimension82; case Dimension83; case Dimension84; case Dimension85;
    case Dimension86; case Dimension87; case Dimension88; case Dimension89; case Dimension90;
    case Dimension91; case Dimension92; case Dimension93; case Dimension94; case Dimension95;
    case Dimension96; case Dimension97; case Dimension98; case Dimension99; case Dimension100;
    case Dimension101; case Dimension102; case Dimension103; case Dimension104; case Dimension105;
    case Dimension106; case Dimension107; case Dimension108; case Dimension109; case Dimension110;
    case Dimension111; case Dimension112; case Dimension113; case Dimension114; case Dimension115;
    case Dimension116; case Dimension117; case Dimension118; case Dimension119; case Dimension120;
    case Dimension121; case Dimension122; case Dimension123; case Dimension124; case Dimension125;
    case Dimension126; case Dimension127; case Dimension128; case Dimension129; case Dimension130;
    case Dimension131; case Dimension132; case Dimension133; case Dimension134; case Dimension135;
    case Dimension136; case Dimension137; case Dimension138; case Dimension139; case Dimension140;
    case Dimension141; case Dimension142; case Dimension143; case Dimension144; case Dimension145;
    case Dimension146; case Dimension147; case Dimension148; case Dimension149; case Dimension150;
    case Dimension151; case Dimension152; case Dimension153; case Dimension154; case Dimension155;
    case Dimension156; case Dimension157; case Dimension158; case Dimension159; case Dimension160;
    case Dimension161; case Dimension162; case Dimension163; case Dimension164; case Dimension165;
    case Dimension166; case Dimension167; case Dimension168; case Dimension169; case Dimension170;
    case Dimension171; case Dimension172; case Dimension173; case Dimension174; case Dimension175;
    case Dimension176; case Dimension177; case Dimension178; case Dimension179; case Dimension180;
    case Dimension181; case Dimension182; case Dimension183; case Dimension184; case Dimension185;
    case Dimension186; case Dimension187; case Dimension188; case Dimension189; case Dimension190;
    case Dimension191; case Dimension192; case Dimension193; case Dimension194; case Dimension195;
    case Dimension196; case Dimension197; case Dimension198; case Dimension199; case Dimension200;
    case Metric1; case Metric2; case Metric3; case Metric4; case Metric5;
    case Metric6; case Metric7; case Metric8; case Metric9; case Metric10;
    case Metric11; case Metric12; case Metric13; case Metric14; case Metric15;
    case Metric16; case Metric17; case Metric18; case Metric19; case Metric20;
    case Metric21; case Metric22; case Metric23; case Metric24; case Metric25;
    case Metric26; case Metric27; case Metric28; case Metric29; case Metric30;
    case Metric31; case Metric32; case Metric33; case Metric34; case Metric35;
    case Metric36; case Metric37; case Metric38; case Metric39; case Metric40;
    case Metric41; case Metric42; case Metric43; case Metric44; case Metric45;
    case Metric46; case Metric47; case Metric48; case Metric49; case Metric50;
    case Metric51; case Metric52; case Metric53; case Metric54; case Metric55;
    case Metric56; case Metric57; case Metric58; case Metric59; case Metric60;
    case Metric61; case Metric62; case Metric63; case Metric64; case Metric65;
    case Metric66; case Metric67; case Metric68; case Metric69; case Metric70;
    case Metric71; case Metric72; case Metric73; case Metric74; case Metric75;
    case Metric76; case Metric77; case Metric78; case Metric79; case Metric80;
    case Metric81; case Metric82; case Metric83; case Metric84; case Metric85;
    case Metric86; case Metric87; case Metric88; case Metric89; case Metric90;
    case Metric91; case Metric92; case Metric93; case Metric94; case Metric95;
    case Metric96; case Metric97; case Metric98; case Metric99; case Metric100;
    case Metric101; case Metric102; case Metric103; case Metric104; case Metric105;
    case Metric106; case Metric107; case Metric108; case Metric109; case Metric110;
    case Metric111; case Metric112; case Metric113; case Metric114; case Metric115;
    case Metric116; case Metric117; case Metric118; case Metric119; case Metric120;
    case Metric121; case Metric122; case Metric123; case Metric124; case Metric125;
    case Metric126; case Metric127; case Metric128; case Metric129; case Metric130;
    case Metric131; case Metric132; case Metric133; case Metric134; case Metric135;
    case Metric136; case Metric137; case Metric138; case Metric139; case Metric140;
    case Metric141; case Metric142; case Metric143; case Metric144; case Metric145;
    case Metric146; case Metric147; case Metric148; case Metric149; case Metric150;
    case Metric151; case Metric152; case Metric153; case Metric154; case Metric155;
    case Metric156; case Metric157; case Metric158; case Metric159; case Metric160;
    case Metric161; case Metric162; case Metric163; case Metric164; case Metric165;
    case Metric166; case Metric167; case Metric168; case Metric169; case Metric170;
    case Metric171; case Metric172; case Metric173; case Metric174; case Metric175;
    case Metric176; case Metric177; case Metric178; case Metric179; case Metric180;
    case Metric181; case Metric182; case Metric183; case Metric184; case Metric185;
    case Metric186; case Metric187; case Metric188; case Metric189; case Metric190;
    case Metric191; case Metric192; case Metric193; case Metric194; case Metric195;
    case Metric196; case Metric197; case Metric198; case Metric199; case Metric200;
    var description:String {
        switch self {
        case .Dimension1: return "cd1";
        case .Dimension2: return "cd2";
        case .Dimension3: return "cd3";
        case .Dimension4: return "cd4";
        case .Dimension5: return "cd5";
        case .Dimension6: return "cd6";
        case .Dimension7: return "cd7";
        case .Dimension8: return "cd8";
        case .Dimension9: return "cd9";
        case .Dimension10: return "cd10";
        case .Dimension11: return "cd11";
        case .Dimension12: return "cd12";
        case .Dimension13: return "cd13";
        case .Dimension14: return "cd14";
        case .Dimension15: return "cd15";
        case .Dimension16: return "cd16";
        case .Dimension17: return "cd17";
        case .Dimension18: return "cd18";
        case .Dimension19: return "cd19";
        case .Dimension20: return "cd20";
        case .Dimension21: return "cd21";
        case .Dimension22: return "cd22";
        case .Dimension23: return "cd23";
        case .Dimension24: return "cd24";
        case .Dimension25: return "cd25";
        case .Dimension26: return "cd26";
        case .Dimension27: return "cd27";
        case .Dimension28: return "cd28";
        case .Dimension29: return "cd29";
        case .Dimension30: return "cd30";
        case .Dimension31: return "cd31";
        case .Dimension32: return "cd32";
        case .Dimension33: return "cd33";
        case .Dimension34: return "cd34";
        case .Dimension35: return "cd35";
        case .Dimension36: return "cd36";
        case .Dimension37: return "cd37";
        case .Dimension38: return "cd38";
        case .Dimension39: return "cd39";
        case .Dimension40: return "cd40";
        case .Dimension41: return "cd41";
        case .Dimension42: return "cd42";
        case .Dimension43: return "cd43";
        case .Dimension44: return "cd44";
        case .Dimension45: return "cd45";
        case .Dimension46: return "cd46";
        case .Dimension47: return "cd47";
        case .Dimension48: return "cd48";
        case .Dimension49: return "cd49";
        case .Dimension50: return "cd50";
        case .Dimension51: return "cd51";
        case .Dimension52: return "cd52";
        case .Dimension53: return "cd53";
        case .Dimension54: return "cd54";
        case .Dimension55: return "cd55";
        case .Dimension56: return "cd56";
        case .Dimension57: return "cd57";
        case .Dimension58: return "cd58";
        case .Dimension59: return "cd59";
        case .Dimension60: return "cd60";
        case .Dimension61: return "cd61";
        case .Dimension62: return "cd62";
        case .Dimension63: return "cd63";
        case .Dimension64: return "cd64";
        case .Dimension65: return "cd65";
        case .Dimension66: return "cd66";
        case .Dimension67: return "cd67";
        case .Dimension68: return "cd68";
        case .Dimension69: return "cd69";
        case .Dimension70: return "cd70";
        case .Dimension71: return "cd71";
        case .Dimension72: return "cd72";
        case .Dimension73: return "cd73";
        case .Dimension74: return "cd74";
        case .Dimension75: return "cd75";
        case .Dimension76: return "cd76";
        case .Dimension77: return "cd77";
        case .Dimension78: return "cd78";
        case .Dimension79: return "cd79";
        case .Dimension80: return "cd80";
        case .Dimension81: return "cd81";
        case .Dimension82: return "cd82";
        case .Dimension83: return "cd83";
        case .Dimension84: return "cd84";
        case .Dimension85: return "cd85";
        case .Dimension86: return "cd86";
        case .Dimension87: return "cd87";
        case .Dimension88: return "cd88";
        case .Dimension89: return "cd89";
        case .Dimension90: return "cd90";
        case .Dimension91: return "cd91";
        case .Dimension92: return "cd92";
        case .Dimension93: return "cd93";
        case .Dimension94: return "cd94";
        case .Dimension95: return "cd95";
        case .Dimension96: return "cd96";
        case .Dimension97: return "cd97";
        case .Dimension98: return "cd98";
        case .Dimension99: return "cd99";
        case .Dimension100: return "cd100";
        case .Dimension101: return "cd101";
        case .Dimension102: return "cd102";
        case .Dimension103: return "cd103";
        case .Dimension104: return "cd104";
        case .Dimension105: return "cd105";
        case .Dimension106: return "cd106";
        case .Dimension107: return "cd107";
        case .Dimension108: return "cd108";
        case .Dimension109: return "cd109";
        case .Dimension110: return "cd110";
        case .Dimension111: return "cd111";
        case .Dimension112: return "cd112";
        case .Dimension113: return "cd113";
        case .Dimension114: return "cd114";
        case .Dimension115: return "cd115";
        case .Dimension116: return "cd116";
        case .Dimension117: return "cd117";
        case .Dimension118: return "cd118";
        case .Dimension119: return "cd119";
        case .Dimension120: return "cd120";
        case .Dimension121: return "cd121";
        case .Dimension122: return "cd122";
        case .Dimension123: return "cd123";
        case .Dimension124: return "cd124";
        case .Dimension125: return "cd125";
        case .Dimension126: return "cd126";
        case .Dimension127: return "cd127";
        case .Dimension128: return "cd128";
        case .Dimension129: return "cd129";
        case .Dimension130: return "cd130";
        case .Dimension131: return "cd131";
        case .Dimension132: return "cd132";
        case .Dimension133: return "cd133";
        case .Dimension134: return "cd134";
        case .Dimension135: return "cd135";
        case .Dimension136: return "cd136";
        case .Dimension137: return "cd137";
        case .Dimension138: return "cd138";
        case .Dimension139: return "cd139";
        case .Dimension140: return "cd140";
        case .Dimension141: return "cd141";
        case .Dimension142: return "cd142";
        case .Dimension143: return "cd143";
        case .Dimension144: return "cd144";
        case .Dimension145: return "cd145";
        case .Dimension146: return "cd146";
        case .Dimension147: return "cd147";
        case .Dimension148: return "cd148";
        case .Dimension149: return "cd149";
        case .Dimension150: return "cd150";
        case .Dimension151: return "cd151";
        case .Dimension152: return "cd152";
        case .Dimension153: return "cd153";
        case .Dimension154: return "cd154";
        case .Dimension155: return "cd155";
        case .Dimension156: return "cd156";
        case .Dimension157: return "cd157";
        case .Dimension158: return "cd158";
        case .Dimension159: return "cd159";
        case .Dimension160: return "cd160";
        case .Dimension161: return "cd161";
        case .Dimension162: return "cd162";
        case .Dimension163: return "cd163";
        case .Dimension164: return "cd164";
        case .Dimension165: return "cd165";
        case .Dimension166: return "cd166";
        case .Dimension167: return "cd167";
        case .Dimension168: return "cd168";
        case .Dimension169: return "cd169";
        case .Dimension170: return "cd170";
        case .Dimension171: return "cd171";
        case .Dimension172: return "cd172";
        case .Dimension173: return "cd173";
        case .Dimension174: return "cd174";
        case .Dimension175: return "cd175";
        case .Dimension176: return "cd176";
        case .Dimension177: return "cd177";
        case .Dimension178: return "cd178";
        case .Dimension179: return "cd179";
        case .Dimension180: return "cd180";
        case .Dimension181: return "cd181";
        case .Dimension182: return "cd182";
        case .Dimension183: return "cd183";
        case .Dimension184: return "cd184";
        case .Dimension185: return "cd185";
        case .Dimension186: return "cd186";
        case .Dimension187: return "cd187";
        case .Dimension188: return "cd188";
        case .Dimension189: return "cd189";
        case .Dimension190: return "cd190";
        case .Dimension191: return "cd191";
        case .Dimension192: return "cd192";
        case .Dimension193: return "cd193";
        case .Dimension194: return "cd194";
        case .Dimension195: return "cd195";
        case .Dimension196: return "cd196";
        case .Dimension197: return "cd197";
        case .Dimension198: return "cd198";
        case .Dimension199: return "cd199";
        case .Dimension200: return "cd200";
        case .Metric1: return "cm1";
        case .Metric2: return "cm2";
        case .Metric3: return "cm3";
        case .Metric4: return "cm4";
        case .Metric5: return "cm5";
        case .Metric6: return "cm6";
        case .Metric7: return "cm7";
        case .Metric8: return "cm8";
        case .Metric9: return "cm9";
        case .Metric10: return "cm10";
        case .Metric11: return "cm11";
        case .Metric12: return "cm12";
        case .Metric13: return "cm13";
        case .Metric14: return "cm14";
        case .Metric15: return "cm15";
        case .Metric16: return "cm16";
        case .Metric17: return "cm17";
        case .Metric18: return "cm18";
        case .Metric19: return "cm19";
        case .Metric20: return "cm20";
        case .Metric21: return "cm21";
        case .Metric22: return "cm22";
        case .Metric23: return "cm23";
        case .Metric24: return "cm24";
        case .Metric25: return "cm25";
        case .Metric26: return "cm26";
        case .Metric27: return "cm27";
        case .Metric28: return "cm28";
        case .Metric29: return "cm29";
        case .Metric30: return "cm30";
        case .Metric31: return "cm31";
        case .Metric32: return "cm32";
        case .Metric33: return "cm33";
        case .Metric34: return "cm34";
        case .Metric35: return "cm35";
        case .Metric36: return "cm36";
        case .Metric37: return "cm37";
        case .Metric38: return "cm38";
        case .Metric39: return "cm39";
        case .Metric40: return "cm40";
        case .Metric41: return "cm41";
        case .Metric42: return "cm42";
        case .Metric43: return "cm43";
        case .Metric44: return "cm44";
        case .Metric45: return "cm45";
        case .Metric46: return "cm46";
        case .Metric47: return "cm47";
        case .Metric48: return "cm48";
        case .Metric49: return "cm49";
        case .Metric50: return "cm50";
        case .Metric51: return "cm51";
        case .Metric52: return "cm52";
        case .Metric53: return "cm53";
        case .Metric54: return "cm54";
        case .Metric55: return "cm55";
        case .Metric56: return "cm56";
        case .Metric57: return "cm57";
        case .Metric58: return "cm58";
        case .Metric59: return "cm59";
        case .Metric60: return "cm60";
        case .Metric61: return "cm61";
        case .Metric62: return "cm62";
        case .Metric63: return "cm63";
        case .Metric64: return "cm64";
        case .Metric65: return "cm65";
        case .Metric66: return "cm66";
        case .Metric67: return "cm67";
        case .Metric68: return "cm68";
        case .Metric69: return "cm69";
        case .Metric70: return "cm70";
        case .Metric71: return "cm71";
        case .Metric72: return "cm72";
        case .Metric73: return "cm73";
        case .Metric74: return "cm74";
        case .Metric75: return "cm75";
        case .Metric76: return "cm76";
        case .Metric77: return "cm77";
        case .Metric78: return "cm78";
        case .Metric79: return "cm79";
        case .Metric80: return "cm80";
        case .Metric81: return "cm81";
        case .Metric82: return "cm82";
        case .Metric83: return "cm83";
        case .Metric84: return "cm84";
        case .Metric85: return "cm85";
        case .Metric86: return "cm86";
        case .Metric87: return "cm87";
        case .Metric88: return "cm88";
        case .Metric89: return "cm89";
        case .Metric90: return "cm90";
        case .Metric91: return "cm91";
        case .Metric92: return "cm92";
        case .Metric93: return "cm93";
        case .Metric94: return "cm94";
        case .Metric95: return "cm95";
        case .Metric96: return "cm96";
        case .Metric97: return "cm97";
        case .Metric98: return "cm98";
        case .Metric99: return "cm99";
        case .Metric100: return "cm100";
        case .Metric101: return "cm101";
        case .Metric102: return "cm102";
        case .Metric103: return "cm103";
        case .Metric104: return "cm104";
        case .Metric105: return "cm105";
        case .Metric106: return "cm106";
        case .Metric107: return "cm107";
        case .Metric108: return "cm108";
        case .Metric109: return "cm109";
        case .Metric110: return "cm110";
        case .Metric111: return "cm111";
        case .Metric112: return "cm112";
        case .Metric113: return "cm113";
        case .Metric114: return "cm114";
        case .Metric115: return "cm115";
        case .Metric116: return "cm116";
        case .Metric117: return "cm117";
        case .Metric118: return "cm118";
        case .Metric119: return "cm119";
        case .Metric120: return "cm120";
        case .Metric121: return "cm121";
        case .Metric122: return "cm122";
        case .Metric123: return "cm123";
        case .Metric124: return "cm124";
        case .Metric125: return "cm125";
        case .Metric126: return "cm126";
        case .Metric127: return "cm127";
        case .Metric128: return "cm128";
        case .Metric129: return "cm129";
        case .Metric130: return "cm130";
        case .Metric131: return "cm131";
        case .Metric132: return "cm132";
        case .Metric133: return "cm133";
        case .Metric134: return "cm134";
        case .Metric135: return "cm135";
        case .Metric136: return "cm136";
        case .Metric137: return "cm137";
        case .Metric138: return "cm138";
        case .Metric139: return "cm139";
        case .Metric140: return "cm140";
        case .Metric141: return "cm141";
        case .Metric142: return "cm142";
        case .Metric143: return "cm143";
        case .Metric144: return "cm144";
        case .Metric145: return "cm145";
        case .Metric146: return "cm146";
        case .Metric147: return "cm147";
        case .Metric148: return "cm148";
        case .Metric149: return "cm149";
        case .Metric150: return "cm150";
        case .Metric151: return "cm151";
        case .Metric152: return "cm152";
        case .Metric153: return "cm153";
        case .Metric154: return "cm154";
        case .Metric155: return "cm155";
        case .Metric156: return "cm156";
        case .Metric157: return "cm157";
        case .Metric158: return "cm158";
        case .Metric159: return "cm159";
        case .Metric160: return "cm160";
        case .Metric161: return "cm161";
        case .Metric162: return "cm162";
        case .Metric163: return "cm163";
        case .Metric164: return "cm164";
        case .Metric165: return "cm165";
        case .Metric166: return "cm166";
        case .Metric167: return "cm167";
        case .Metric168: return "cm168";
        case .Metric169: return "cm169";
        case .Metric170: return "cm170";
        case .Metric171: return "cm171";
        case .Metric172: return "cm172";
        case .Metric173: return "cm173";
        case .Metric174: return "cm174";
        case .Metric175: return "cm175";
        case .Metric176: return "cm176";
        case .Metric177: return "cm177";
        case .Metric178: return "cm178";
        case .Metric179: return "cm179";
        case .Metric180: return "cm180";
        case .Metric181: return "cm181";
        case .Metric182: return "cm182";
        case .Metric183: return "cm183";
        case .Metric184: return "cm184";
        case .Metric185: return "cm185";
        case .Metric186: return "cm186";
        case .Metric187: return "cm187";
        case .Metric188: return "cm188";
        case .Metric189: return "cm189";
        case .Metric190: return "cm190";
        case .Metric191: return "cm191";
        case .Metric192: return "cm192";
        case .Metric193: return "cm193";
        case .Metric194: return "cm194";
        case .Metric195: return "cm195";
        case .Metric196: return "cm196";
        case .Metric197: return "cm197";
        case .Metric198: return "cm198";
        case .Metric199: return "cm199";
        case .Metric200: return "cm200";
        }
    }
}

enum GAHitKey :CustomStringConvertible{
    case UserID;
    case Title;
    case EventCategory;
    case EventAction;
    case EventLabel;
    case EventValue;
    case NonInteraction;
    case CurrencyCode;
    var description:String{
        switch self {
          case .UserID: return "uid"
          case .Title: return "cd"
          case .EventCategory: return "ec"
          case .EventAction: return "ea"
          case .EventLabel: return "el"
          case .EventValue: return "ev"
          case .NonInteraction: return "ni"
          case .CurrencyCode : return "cu"
        }
    }
}

enum GAEcommerceStepKey:CustomStringConvertible{
    case Impression;
    case Detail;
    case Click;
    case Add;
    case Remove;
    case Checkout;
    case Purchase;
    case Refund;
    case PromotionImpression;
    case PromotionClick;
    var description: String{
        switch self {
          case .Impression: return "impression"
          case .Click: return "click"
          case .Detail: return "detail"
          case .Add: return "add"
          case .Remove: return "remove"
          case .Checkout: return "checkout"
          case .Purchase: return "purchase"
          case .Refund: return "refund"
          case .PromotionImpression: return "promotionimpression"
          case .PromotionClick: return "promotionclick"
        }
    }
}

enum GAActionFieldKey:CustomStringConvertible{
    case TransactionID;
    case TransactionRevenue;
    case TransactionTax;
    case TransactionShipping;
    case TransactionCouponCode
    case TransactionAffiliation;
    case ProductActionList;
    case CheckoutStep;
    case CheckoutOptions;
    var description: String{
        switch self {
          case .TransactionID: return "ti"
          case .TransactionRevenue: return "tr"
          case .TransactionTax: return "tt"
          case .TransactionShipping: return "ts"
          case .TransactionCouponCode: return "tcc"
          case .TransactionAffiliation: return "ta"
          case .ProductActionList: return "pal"
          case .CheckoutStep: return "cos"
          case .CheckoutOptions: return "col"
        }
    }
}

enum GAProductKey:CustomStringConvertible{
    case ProductID;
    case ProductName;
    case ProductBrand;
    case ProductCategory;
    case ProductVariant;
    case ProductPrice;
    case ProductQuantity;
    case ProductCouponCode;
    case ProductPosition;
    case ImpressionList;
    case ProductDimension1; case ProductDimension2; case ProductDimension3; case ProductDimension4; case ProductDimension5;
    case ProductDimension6; case ProductDimension7; case ProductDimension8; case ProductDimension9; case ProductDimension10;
    case ProductDimension11; case ProductDimension12; case ProductDimension13; case ProductDimension14; case ProductDimension15;
    case ProductDimension16; case ProductDimension17; case ProductDimension18; case ProductDimension19; case ProductDimension20;
    case ProductDimension21; case ProductDimension22; case ProductDimension23; case ProductDimension24; case ProductDimension25;
    case ProductDimension26; case ProductDimension27; case ProductDimension28; case ProductDimension29; case ProductDimension30;
    case ProductDimension31; case ProductDimension32; case ProductDimension33; case ProductDimension34; case ProductDimension35;
    case ProductDimension36; case ProductDimension37; case ProductDimension38; case ProductDimension39; case ProductDimension40;
    case ProductDimension41; case ProductDimension42; case ProductDimension43; case ProductDimension44; case ProductDimension45;
    case ProductDimension46; case ProductDimension47; case ProductDimension48; case ProductDimension49; case ProductDimension50;
    case ProductDimension51; case ProductDimension52; case ProductDimension53; case ProductDimension54; case ProductDimension55;
    case ProductDimension56; case ProductDimension57; case ProductDimension58; case ProductDimension59; case ProductDimension60;
    case ProductDimension61; case ProductDimension62; case ProductDimension63; case ProductDimension64; case ProductDimension65;
    case ProductDimension66; case ProductDimension67; case ProductDimension68; case ProductDimension69; case ProductDimension70;
    case ProductDimension71; case ProductDimension72; case ProductDimension73; case ProductDimension74; case ProductDimension75;
    case ProductDimension76; case ProductDimension77; case ProductDimension78; case ProductDimension79; case ProductDimension80;
    case ProductDimension81; case ProductDimension82; case ProductDimension83; case ProductDimension84; case ProductDimension85;
    case ProductDimension86; case ProductDimension87; case ProductDimension88; case ProductDimension89; case ProductDimension90;
    case ProductDimension91; case ProductDimension92; case ProductDimension93; case ProductDimension94; case ProductDimension95;
    case ProductDimension96; case ProductDimension97; case ProductDimension98; case ProductDimension99; case ProductDimension100;
    case ProductDimension101; case ProductDimension102; case ProductDimension103; case ProductDimension104; case ProductDimension105;
    case ProductDimension106; case ProductDimension107; case ProductDimension108; case ProductDimension109; case ProductDimension110;
    case ProductDimension111; case ProductDimension112; case ProductDimension113; case ProductDimension114; case ProductDimension115;
    case ProductDimension116; case ProductDimension117; case ProductDimension118; case ProductDimension119; case ProductDimension120;
    case ProductDimension121; case ProductDimension122; case ProductDimension123; case ProductDimension124; case ProductDimension125;
    case ProductDimension126; case ProductDimension127; case ProductDimension128; case ProductDimension129; case ProductDimension130;
    case ProductDimension131; case ProductDimension132; case ProductDimension133; case ProductDimension134; case ProductDimension135;
    case ProductDimension136; case ProductDimension137; case ProductDimension138; case ProductDimension139; case ProductDimension140;
    case ProductDimension141; case ProductDimension142; case ProductDimension143; case ProductDimension144; case ProductDimension145;
    case ProductDimension146; case ProductDimension147; case ProductDimension148; case ProductDimension149; case ProductDimension150;
    case ProductDimension151; case ProductDimension152; case ProductDimension153; case ProductDimension154; case ProductDimension155;
    case ProductDimension156; case ProductDimension157; case ProductDimension158; case ProductDimension159; case ProductDimension160;
    case ProductDimension161; case ProductDimension162; case ProductDimension163; case ProductDimension164; case ProductDimension165;
    case ProductDimension166; case ProductDimension167; case ProductDimension168; case ProductDimension169; case ProductDimension170;
    case ProductDimension171; case ProductDimension172; case ProductDimension173; case ProductDimension174; case ProductDimension175;
    case ProductDimension176; case ProductDimension177; case ProductDimension178; case ProductDimension179; case ProductDimension180;
    case ProductDimension181; case ProductDimension182; case ProductDimension183; case ProductDimension184; case ProductDimension185;
    case ProductDimension186; case ProductDimension187; case ProductDimension188; case ProductDimension189; case ProductDimension190;
    case ProductDimension191; case ProductDimension192; case ProductDimension193; case ProductDimension194; case ProductDimension195;
    case ProductDimension196; case ProductDimension197; case ProductDimension198; case ProductDimension199; case ProductDimension200;
    case ProductMetric1; case ProductMetric2; case ProductMetric3; case ProductMetric4; case ProductMetric5;
    case ProductMetric6; case ProductMetric7; case ProductMetric8; case ProductMetric9; case ProductMetric10;
    case ProductMetric11; case ProductMetric12; case ProductMetric13; case ProductMetric14; case ProductMetric15;
    case ProductMetric16; case ProductMetric17; case ProductMetric18; case ProductMetric19; case ProductMetric20;
    case ProductMetric21; case ProductMetric22; case ProductMetric23; case ProductMetric24; case ProductMetric25;
    case ProductMetric26; case ProductMetric27; case ProductMetric28; case ProductMetric29; case ProductMetric30;
    case ProductMetric31; case ProductMetric32; case ProductMetric33; case ProductMetric34; case ProductMetric35;
    case ProductMetric36; case ProductMetric37; case ProductMetric38; case ProductMetric39; case ProductMetric40;
    case ProductMetric41; case ProductMetric42; case ProductMetric43; case ProductMetric44; case ProductMetric45;
    case ProductMetric46; case ProductMetric47; case ProductMetric48; case ProductMetric49; case ProductMetric50;
    case ProductMetric51; case ProductMetric52; case ProductMetric53; case ProductMetric54; case ProductMetric55;
    case ProductMetric56; case ProductMetric57; case ProductMetric58; case ProductMetric59; case ProductMetric60;
    case ProductMetric61; case ProductMetric62; case ProductMetric63; case ProductMetric64; case ProductMetric65;
    case ProductMetric66; case ProductMetric67; case ProductMetric68; case ProductMetric69; case ProductMetric70;
    case ProductMetric71; case ProductMetric72; case ProductMetric73; case ProductMetric74; case ProductMetric75;
    case ProductMetric76; case ProductMetric77; case ProductMetric78; case ProductMetric79; case ProductMetric80;
    case ProductMetric81; case ProductMetric82; case ProductMetric83; case ProductMetric84; case ProductMetric85;
    case ProductMetric86; case ProductMetric87; case ProductMetric88; case ProductMetric89; case ProductMetric90;
    case ProductMetric91; case ProductMetric92; case ProductMetric93; case ProductMetric94; case ProductMetric95;
    case ProductMetric96; case ProductMetric97; case ProductMetric98; case ProductMetric99; case ProductMetric100;
    case ProductMetric101; case ProductMetric102; case ProductMetric103; case ProductMetric104; case ProductMetric105;
    case ProductMetric106; case ProductMetric107; case ProductMetric108; case ProductMetric109; case ProductMetric110;
    case ProductMetric111; case ProductMetric112; case ProductMetric113; case ProductMetric114; case ProductMetric115;
    case ProductMetric116; case ProductMetric117; case ProductMetric118; case ProductMetric119; case ProductMetric120;
    case ProductMetric121; case ProductMetric122; case ProductMetric123; case ProductMetric124; case ProductMetric125;
    case ProductMetric126; case ProductMetric127; case ProductMetric128; case ProductMetric129; case ProductMetric130;
    case ProductMetric131; case ProductMetric132; case ProductMetric133; case ProductMetric134; case ProductMetric135;
    case ProductMetric136; case ProductMetric137; case ProductMetric138; case ProductMetric139; case ProductMetric140;
    case ProductMetric141; case ProductMetric142; case ProductMetric143; case ProductMetric144; case ProductMetric145;
    case ProductMetric146; case ProductMetric147; case ProductMetric148; case ProductMetric149; case ProductMetric150;
    case ProductMetric151; case ProductMetric152; case ProductMetric153; case ProductMetric154; case ProductMetric155;
    case ProductMetric156; case ProductMetric157; case ProductMetric158; case ProductMetric159; case ProductMetric160;
    case ProductMetric161; case ProductMetric162; case ProductMetric163; case ProductMetric164; case ProductMetric165;
    case ProductMetric166; case ProductMetric167; case ProductMetric168; case ProductMetric169; case ProductMetric170;
    case ProductMetric171; case ProductMetric172; case ProductMetric173; case ProductMetric174; case ProductMetric175;
    case ProductMetric176; case ProductMetric177; case ProductMetric178; case ProductMetric179; case ProductMetric180;
    case ProductMetric181; case ProductMetric182; case ProductMetric183; case ProductMetric184; case ProductMetric185;
    case ProductMetric186; case ProductMetric187; case ProductMetric188; case ProductMetric189; case ProductMetric190;
    case ProductMetric191; case ProductMetric192; case ProductMetric193; case ProductMetric194; case ProductMetric195;
    case ProductMetric196; case ProductMetric197; case ProductMetric198; case ProductMetric199; case ProductMetric200;
    var description: String{
        switch self {
          case .ProductID: return "prid"
          case .ProductName: return "prnm"
          case .ProductBrand: return "prbr"
          case .ProductCategory: return "prca"
          case .ProductVariant: return "prva"
          case .ProductPrice: return "prpr"
          case .ProductQuantity: return "prqt"
          case .ProductCouponCode: return "prcc"
          case .ProductPosition: return "prps"
          case .ImpressionList: return "prlist"
          case .ProductDimension1: return "prdcd1"; case .ProductDimension2: return "prcd2"
          case .ProductDimension3: return "prcd3"; case .ProductDimension4: return "prcd4"
          case .ProductDimension5: return "prcd5"; case .ProductDimension6: return "prcd6"
          case .ProductDimension7: return "prcd7"; case .ProductDimension8: return "prcd8"
          case .ProductDimension9: return "prcd9"; case .ProductDimension10: return "prcd10"
          case .ProductDimension11: return "prcd11"; case .ProductDimension12: return "prcd12"
          case .ProductDimension13: return "prcd13"; case .ProductDimension14: return "prcd14"
          case .ProductDimension15: return "prcd15"; case .ProductDimension16: return "prcd16"
          case .ProductDimension17: return "prcd17"; case .ProductDimension18: return "prcd18"
          case .ProductDimension19: return "prcd19"; case .ProductDimension20: return "prcd20"
          case .ProductDimension21: return "prcd21"; case .ProductDimension22: return "prcd22"
          case .ProductDimension23: return "prcd23"; case .ProductDimension24: return "prcd24"
          case .ProductDimension25: return "prcd25"; case .ProductDimension26: return "prcd26"
          case .ProductDimension27: return "prcd27"; case .ProductDimension28: return "prcd28"
          case .ProductDimension29: return "prcd29"; case .ProductDimension30: return "prcd30"
          case .ProductDimension31: return "prcd31"; case .ProductDimension32: return "prcd32"
          case .ProductDimension33: return "prcd33"; case .ProductDimension34: return "prcd34"
          case .ProductDimension35: return "prcd35"; case .ProductDimension36: return "prcd36"
          case .ProductDimension37: return "prcd37"; case .ProductDimension38: return "prcd38"
          case .ProductDimension39: return "prcd39"; case .ProductDimension40: return "prcd40"
          case .ProductDimension41: return "prcd41"; case .ProductDimension42: return "prcd42"
          case .ProductDimension43: return "prcd43"; case .ProductDimension44: return "prcd44"
          case .ProductDimension45: return "prcd45"; case .ProductDimension46: return "prcd46"
          case .ProductDimension47: return "prcd47"; case .ProductDimension48: return "prcd48"
          case .ProductDimension49: return "prcd49"; case .ProductDimension50: return "prcd50"
          case .ProductDimension51: return "prcd51"; case .ProductDimension52: return "prcd52"
          case .ProductDimension53: return "prcd53"; case .ProductDimension54: return "prcd54"
          case .ProductDimension55: return "prcd55"; case .ProductDimension56: return "prcd56"
          case .ProductDimension57: return "prcd57"; case .ProductDimension58: return "prcd58"
          case .ProductDimension59: return "prcd59"; case .ProductDimension60: return "prcd60"
          case .ProductDimension61: return "prcd61"; case .ProductDimension62: return "prcd62"
          case .ProductDimension63: return "prcd63"; case .ProductDimension64: return "prcd64"
          case .ProductDimension65: return "prcd65"; case .ProductDimension66: return "prcd66"
          case .ProductDimension67: return "prcd67"; case .ProductDimension68: return "prcd68"
          case .ProductDimension69: return "prcd69"; case .ProductDimension70: return "prcd70"
          case .ProductDimension71: return "prcd71"; case .ProductDimension72: return "prcd72"
          case .ProductDimension73: return "prcd73"; case .ProductDimension74: return "prcd74"
          case .ProductDimension75: return "prcd75"; case .ProductDimension76: return "prcd76"
          case .ProductDimension77: return "prcd77"; case .ProductDimension78: return "prcd78"
          case .ProductDimension79: return "prcd79"; case .ProductDimension80: return "prcd80"
          case .ProductDimension81: return "prcd81"; case .ProductDimension82: return "prcd82"
          case .ProductDimension83: return "prcd83"; case .ProductDimension84: return "prcd84"
          case .ProductDimension85: return "prcd85"; case .ProductDimension86: return "prcd86"
          case .ProductDimension87: return "prcd87"; case .ProductDimension88: return "prcd88"
          case .ProductDimension89: return "prcd89"; case .ProductDimension90: return "prcd90"
          case .ProductDimension91: return "prcd91"; case .ProductDimension92: return "prcd92"
          case .ProductDimension93: return "prcd93"; case .ProductDimension94: return "prcd94"
          case .ProductDimension95: return "prcd95"; case .ProductDimension96: return "prcd96"
          case .ProductDimension97: return "prcd97"; case .ProductDimension98: return "prcd98"
          case .ProductDimension99: return "prcd99"; case .ProductDimension100: return "prcd100"
          case .ProductDimension101: return "prcd101"; case .ProductDimension102: return "prcd102"
          case .ProductDimension103: return "prcd103"; case .ProductDimension104: return "prcd104"
          case .ProductDimension105: return "prcd105"; case .ProductDimension106: return "prcd106"
          case .ProductDimension107: return "prcd107"; case .ProductDimension108: return "prcd108"
          case .ProductDimension109: return "prcd109"; case .ProductDimension110: return "prcd110"
          case .ProductDimension111: return "prcd111"; case .ProductDimension112: return "prcd112"
          case .ProductDimension113: return "prcd113"; case .ProductDimension114: return "prcd114"
          case .ProductDimension115: return "prcd115"; case .ProductDimension116: return "prcd116"
          case .ProductDimension117: return "prcd117"; case .ProductDimension118: return "prcd118"
          case .ProductDimension119: return "prcd119"; case .ProductDimension120: return "prcd120"
          case .ProductDimension121: return "prcd121"; case .ProductDimension122: return "prcd122"
          case .ProductDimension123: return "prcd123"; case .ProductDimension124: return "prcd124"
          case .ProductDimension125: return "prcd125"; case .ProductDimension126: return "prcd126"
          case .ProductDimension127: return "prcd127"; case .ProductDimension128: return "prcd128"
          case .ProductDimension129: return "prcd129"; case .ProductDimension130: return "prcd130"
          case .ProductDimension131: return "prcd131"; case .ProductDimension132: return "prcd132"
          case .ProductDimension133: return "prcd133"; case .ProductDimension134: return "prcd134"
          case .ProductDimension135: return "prcd135"; case .ProductDimension136: return "prcd136"
          case .ProductDimension137: return "prcd137"; case .ProductDimension138: return "prcd138"
          case .ProductDimension139: return "prcd139"; case .ProductDimension140: return "prcd140"
          case .ProductDimension141: return "prcd141"; case .ProductDimension142: return "prcd142"
          case .ProductDimension143: return "prcd143"; case .ProductDimension144: return "prcd144"
          case .ProductDimension145: return "prcd145"; case .ProductDimension146: return "prcd146"
          case .ProductDimension147: return "prcd147"; case .ProductDimension148: return "prcd148"
          case .ProductDimension149: return "prcd149"; case .ProductDimension150: return "prcd150"
          case .ProductDimension151: return "prcd151"; case .ProductDimension152: return "prcd152"
          case .ProductDimension153: return "prcd153"; case .ProductDimension154: return "prcd154"
          case .ProductDimension155: return "prcd155"; case .ProductDimension156: return "prcd156"
          case .ProductDimension157: return "prcd157"; case .ProductDimension158: return "prcd158"
          case .ProductDimension159: return "prcd159"; case .ProductDimension160: return "prcd160"
          case .ProductDimension161: return "prcd161"; case .ProductDimension162: return "prcd162"
          case .ProductDimension163: return "prcd163"; case .ProductDimension164: return "prcd164"
          case .ProductDimension165: return "prcd165"; case .ProductDimension166: return "prcd166"
          case .ProductDimension167: return "prcd167"; case .ProductDimension168: return "prcd168"
          case .ProductDimension169: return "prcd169"; case .ProductDimension170: return "prcd170"
          case .ProductDimension171: return "prcd171"; case .ProductDimension172: return "prcd172"
          case .ProductDimension173: return "prcd173"; case .ProductDimension174: return "prcd174"
          case .ProductDimension175: return "prcd175"; case .ProductDimension176: return "prcd176"
          case .ProductDimension177: return "prcd177"; case .ProductDimension178: return "prcd178"
          case .ProductDimension179: return "prcd179"; case .ProductDimension180: return "prcd180"
          case .ProductDimension181: return "prcd181"; case .ProductDimension182: return "prcd182"
          case .ProductDimension183: return "prcd183"; case .ProductDimension184: return "prcd184"
          case .ProductDimension185: return "prcd185"; case .ProductDimension186: return "prcd186"
          case .ProductDimension187: return "prcd187"; case .ProductDimension188: return "prcd188"
          case .ProductDimension189: return "prcd189"; case .ProductDimension190: return "prcd190"
          case .ProductDimension191: return "prcd191"; case .ProductDimension192: return "prcd192"
          case .ProductDimension193: return "prcd193"; case .ProductDimension194: return "prcd194"
          case .ProductDimension195: return "prcd195"; case .ProductDimension196: return "prcd196"
          case .ProductDimension197: return "prcd197"; case .ProductDimension198: return "prcd198"
          case .ProductDimension199: return "prcd199"; case .ProductDimension200: return "prcd200"
          case .ProductMetric1: return "prme1"; case .ProductMetric2: return "prme2"
          case .ProductMetric3: return "prme3"; case .ProductMetric4: return "prme4"
          case .ProductMetric5: return "prme5"; case .ProductMetric6: return "prme6"
          case .ProductMetric7: return "prme7"; case .ProductMetric8: return "prme8"
          case .ProductMetric9: return "prme9"; case .ProductMetric10: return "prme10"
          case .ProductMetric11: return "prme11"; case .ProductMetric12: return "prme12"
          case .ProductMetric13: return "prme13"; case .ProductMetric14: return "prme14"
          case .ProductMetric15: return "prme15"; case .ProductMetric16: return "prme16"
          case .ProductMetric17: return "prme17"; case .ProductMetric18: return "prme18"
          case .ProductMetric19: return "prme19"; case .ProductMetric20: return "prme20"
          case .ProductMetric21: return "prme21"; case .ProductMetric22: return "prme22"
          case .ProductMetric23: return "prme23"; case .ProductMetric24: return "prme24"
          case .ProductMetric25: return "prme25"; case .ProductMetric26: return "prme26"
          case .ProductMetric27: return "prme27"; case .ProductMetric28: return "prme28"
          case .ProductMetric29: return "prme29"; case .ProductMetric30: return "prme30"
          case .ProductMetric31: return "prme31"; case .ProductMetric32: return "prme32"
          case .ProductMetric33: return "prme33"; case .ProductMetric34: return "prme34"
          case .ProductMetric35: return "prme35"; case .ProductMetric36: return "prme36"
          case .ProductMetric37: return "prme37"; case .ProductMetric38: return "prme38"
          case .ProductMetric39: return "prme39"; case .ProductMetric40: return "prme40"
          case .ProductMetric41: return "prme41"; case .ProductMetric42: return "prme42"
          case .ProductMetric43: return "prme43"; case .ProductMetric44: return "prme44"
          case .ProductMetric45: return "prme45"; case .ProductMetric46: return "prme46"
          case .ProductMetric47: return "prme47"; case .ProductMetric48: return "prme48"
          case .ProductMetric49: return "prme49"; case .ProductMetric50: return "prme50"
          case .ProductMetric51: return "prme51"; case .ProductMetric52: return "prme52"
          case .ProductMetric53: return "prme53"; case .ProductMetric54: return "prme54"
          case .ProductMetric55: return "prme55"; case .ProductMetric56: return "prme56"
          case .ProductMetric57: return "prme57"; case .ProductMetric58: return "prme58"
          case .ProductMetric59: return "prme59"; case .ProductMetric60: return "prme60"
          case .ProductMetric61: return "prme61"; case .ProductMetric62: return "prme62"
          case .ProductMetric63: return "prme63"; case .ProductMetric64: return "prme64"
          case .ProductMetric65: return "prme65"; case .ProductMetric66: return "prme66"
          case .ProductMetric67: return "prme67"; case .ProductMetric68: return "prme68"
          case .ProductMetric69: return "prme69"; case .ProductMetric70: return "prme70"
          case .ProductMetric71: return "prme71"; case .ProductMetric72: return "prme72"
          case .ProductMetric73: return "prme73"; case .ProductMetric74: return "prme74"
          case .ProductMetric75: return "prme75"; case .ProductMetric76: return "prme76"
          case .ProductMetric77: return "prme77"; case .ProductMetric78: return "prme78"
          case .ProductMetric79: return "prme79"; case .ProductMetric80: return "prme80"
          case .ProductMetric81: return "prme81"; case .ProductMetric82: return "prme82"
          case .ProductMetric83: return "prme83"; case .ProductMetric84: return "prme84"
          case .ProductMetric85: return "prme85"; case .ProductMetric86: return "prme86"
          case .ProductMetric87: return "prme87"; case .ProductMetric88: return "prme88"
          case .ProductMetric89: return "prme89"; case .ProductMetric90: return "prme90"
          case .ProductMetric91: return "prme91"; case .ProductMetric92: return "prme92"
          case .ProductMetric93: return "prme93"; case .ProductMetric94: return "prme94"
          case .ProductMetric95: return "prme95"; case .ProductMetric96: return "prme96"
          case .ProductMetric97: return "prme97"; case .ProductMetric98: return "prme98"
          case .ProductMetric99: return "prme99"; case .ProductMetric100: return "prme100"
          case .ProductMetric101: return "prme101"; case .ProductMetric102: return "prme102"
          case .ProductMetric103: return "prme103"; case .ProductMetric104: return "prme104"
          case .ProductMetric105: return "prme105"; case .ProductMetric106: return "prme106"
          case .ProductMetric107: return "prme107"; case .ProductMetric108: return "prme108"
          case .ProductMetric109: return "prme109"; case .ProductMetric110: return "prme110"
          case .ProductMetric111: return "prme111"; case .ProductMetric112: return "prme112"
          case .ProductMetric113: return "prme113"; case .ProductMetric114: return "prme114"
          case .ProductMetric115: return "prme115"; case .ProductMetric116: return "prme116"
          case .ProductMetric117: return "prme117"; case .ProductMetric118: return "prme118"
          case .ProductMetric119: return "prme119"; case .ProductMetric120: return "prme120"
          case .ProductMetric121: return "prme121"; case .ProductMetric122: return "prme122"
          case .ProductMetric123: return "prme123"; case .ProductMetric124: return "prme124"
          case .ProductMetric125: return "prme125"; case .ProductMetric126: return "prme126"
          case .ProductMetric127: return "prme127"; case .ProductMetric128: return "prme128"
          case .ProductMetric129: return "prme129"; case .ProductMetric130: return "prme130"
          case .ProductMetric131: return "prme131"; case .ProductMetric132: return "prme132"
          case .ProductMetric133: return "prme133"; case .ProductMetric134: return "prme134"
          case .ProductMetric135: return "prme135"; case .ProductMetric136: return "prme136"
          case .ProductMetric137: return "prme137"; case .ProductMetric138: return "prme138"
          case .ProductMetric139: return "prme139"; case .ProductMetric140: return "prme140"
          case .ProductMetric141: return "prme141"; case .ProductMetric142: return "prme142"
          case .ProductMetric143: return "prme143"; case .ProductMetric144: return "prme144"
          case .ProductMetric145: return "prme145"; case .ProductMetric146: return "prme146"
          case .ProductMetric147: return "prme147"; case .ProductMetric148: return "prme148"
          case .ProductMetric149: return "prme149"; case .ProductMetric150: return "prme150"
          case .ProductMetric151: return "prme151"; case .ProductMetric152: return "prme152"
          case .ProductMetric153: return "prme153"; case .ProductMetric154: return "prme154"
          case .ProductMetric155: return "prme155"; case .ProductMetric156: return "prme156"
          case .ProductMetric157: return "prme157"; case .ProductMetric158: return "prme158"
          case .ProductMetric159: return "prme159"; case .ProductMetric160: return "prme160"
          case .ProductMetric161: return "prme161"; case .ProductMetric162: return "prme162"
          case .ProductMetric163: return "prme163"; case .ProductMetric164: return "prme164"
          case .ProductMetric165: return "prme165"; case .ProductMetric166: return "prme166"
          case .ProductMetric167: return "prme167"; case .ProductMetric168: return "prme168"
          case .ProductMetric169: return "prme169"; case .ProductMetric170: return "prme170"
          case .ProductMetric171: return "prme171"; case .ProductMetric172: return "prme172"
          case .ProductMetric173: return "prme173"; case .ProductMetric174: return "prme174"
          case .ProductMetric175: return "prme175"; case .ProductMetric176: return "prme176"
          case .ProductMetric177: return "prme177"; case .ProductMetric178: return "prme178"
          case .ProductMetric179: return "prme179"; case .ProductMetric180: return "prme180"
          case .ProductMetric181: return "prme181"; case .ProductMetric182: return "prme182"
          case .ProductMetric183: return "prme183"; case .ProductMetric184: return "prme184"
          case .ProductMetric185: return "prme185"; case .ProductMetric186: return "prme186"
          case .ProductMetric187: return "prme187"; case .ProductMetric188: return "prme188"
          case .ProductMetric189: return "prme189"; case .ProductMetric190: return "prme190"
          case .ProductMetric191: return "prme191"; case .ProductMetric192: return "prme192"
          case .ProductMetric193: return "prme193"; case .ProductMetric194: return "prme194"
          case .ProductMetric195: return "prme195"; case .ProductMetric196: return "prme196"
          case .ProductMetric197: return "prme197"; case .ProductMetric198: return "prme198"
          case .ProductMetric199: return "prme199"; case .ProductMetric200: return "prme200"
        }
    }
}

func GADataSend_Screen(GAInfo : Dictionary<String, String>){
    var Screen_map = GAInfo
    Screen_map.updateValue("screenview", forKey: "t")
    gaThread(dict : Screen_map);
}

func GADataSend_Event(GAInfo : Dictionary<String,String>) -> Void {
    var Event_map = GAInfo
    Event_map.updateValue("event", forKey: "t")
    gaThread(dict : Event_map);
}

func gaThread(dict: Dictionary<String, String>) {
    let setdata = NSMutableDictionary()
    let tracker = GAI.sharedInstance()?.defaultTracker
    setdata.setValue("UA-115948787-1", forKey: "tid")
    setdata.setValue((tracker?.get(kGAIClientId))!, forKey: "cid")
    setdata.setValue((tracker?.get(kGAIAppName))!, forKey: "an")
    setdata.setValue((tracker?.get(kGAIAppVersion))!, forKey: "av")
    setdata.setValue((tracker?.get(kGAIAppId))!, forKey: "aid")
    setdata.setValue("app", forKey: "ds")
    setdata.setValue("1", forKey: "aip")
    for (key,value) in dict{
        if(key != "cd" && key.contains("cd")){ setdata.setValue(key, forKey: value) }
        if(key.contains("cm")){ setdata.setValue(value, forKey: key) }
        if key == "t"{ setdata.setValue(value, forKey: key) }
        if key == "dl"{ setdata.setValue(value, forKey: key) }
        if key == "dt"{ setdata.setValue(value, forKey: key) }
        if key == "ec"{ setdata.setValue(value, forKey: key) }
        if key == "ea"{ setdata.setValue(value, forKey: key) }
        if key == "el"{ setdata.setValue(value, forKey: key) }
        if key == "ev"{ setdata.setValue(value, forKey: key) }
        if key == "cn"{ setdata.setValue(value, forKey: key) }
        if key == "cs"{ setdata.setValue(value, forKey: key) }
        if key == "cm"{ setdata.setValue(value, forKey: key) }
        if key == "ck"{ setdata.setValue(value, forKey: key) }
        if key == "cc"{ setdata.setValue(value, forKey: key) }
        if key == "ci"{ setdata.setValue(value, forKey: key) }
        if key == "sr"{ setdata.setValue(value, forKey: key) }
        if key == "ul"{ setdata.setValue(value, forKey: key) }
        if key == "cd"{ setdata.setValue(value, forKey: key) }
        if key == "cu"{ setdata.setValue(value, forKey: key) }
        if key == "ni"{ setdata.setValue(value, forKey: key) }
        if key == "pa"{ setdata.setValue(value, forKey: key) }
        if key == "ti"{ setdata.setValue(value, forKey: key) }
        if key == "ta"{ setdata.setValue(value, forKey: key) }
        if key == "tr"{ setdata.setValue(value, forKey: key) }
        if key == "ts"{ setdata.setValue(value, forKey: key) }
        if key == "tt"{ setdata.setValue(value, forKey: key) }
        if key == "tcc"{ setdata.setValue(value, forKey: key) }
        if key == "pal"{ setdata.setValue(value, forKey: key) }
        if key == "cos"{ setdata.setValue(value, forKey: key) }
        if key == "col"{ setdata.setValue(value, forKey: key) }
        if key == "aid"{ setdata.setValue(value, forKey: key) }
        if key == "av"{ setdata.setValue(value, forKey: key) }
        if key == "an"{ setdata.setValue(value, forKey: key) }
        if(key.contains("il")){ setdata.setValue(value, forKey: key) }
        if(key.contains("pr")){ setdata.setValue(value, forKey: key) }
    }
    hitsend(dataset: setdata)
}

func hitsend(dataset : NSMutableDictionary){
    var query = "v=1"
    for (key, value) in dataset{
        let T : String = value as! String
        let A : String = key as! String
        query = query + "&"
        query = query + A
        query = query + "="
        query = query + T
    }
    let GAURL = String(format: "http://www.google-analytics.com/collect")
    var request = URLRequest(url: URL(string: GAURL)!)
    let post = String(format:"\(query)")
    let postData = post.data(using: .utf8, allowLossyConversion: true)
    let postLength = String(postData!.count)
    request.httpMethod = "POST"
    request.setValue(postLength, forHTTPHeaderField: "Content-Length")
    request.setValue("text/html,application/xhtml+xml,application/xml;q=0.9,*-*;q=0.8", forHTTPHeaderField: "Accept")
    request.httpBody = postData
    request.setValue("Mozilla/5.0 (iPhone; CPU iPhone OS 9_1 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13B137 Safari/601.1", forHTTPHeaderField: "User-Agent")
    let oResponseData = URLSession.shared.dataTask(with: request) { (data, response, error) in
        let httperror = response as? HTTPURLResponse
        if httperror?.statusCode != 200 {
            print("error :\(String(describing: httperror?.statusCode))")
        }else{
            print("\nGAData : \(query)")
        }
    }
    oResponseData.resume()
}



func GA_Product(GAProduct: Dictionary<String, Dictionary<String,String>>, GAInfo: NSMutableDictionary) -> NSMutableDictionary{
    var productList = 1;
    for (keys, value) in GAProduct {
        if keys.lowercased().contains("pr"){
            var ProductInfo = GAProduct[keys]
            for (product_key, value) in ProductInfo!{
                if product_key.lowercased() == ("prid") { GAInfo.setValue(value, forKey: "pr" + String(productList) + "id") }
                if product_key.lowercased() == ("prnm") { GAInfo.setValue(value, forKey: "pr" + String(productList) + "nm") }
                if product_key.lowercased() == ("prbr") { GAInfo.setValue(value, forKey: "pr" + String(productList) + "br") }
                if product_key.lowercased() == ("prca") { GAInfo.setValue(value, forKey: "pr" + String(productList) + "ca") }
                if product_key.lowercased() == ("prva") { GAInfo.setValue(value, forKey: "pr" + String(productList) + "va") }
                if product_key.lowercased() == ("prpr") { GAInfo.setValue(value, forKey: "pr" + String(productList) + "pr") }
                if product_key.lowercased() == ("prqt") { GAInfo.setValue(value, forKey: "pr" + String(productList) + "qt") }
                if product_key.lowercased() == ("prcc") { GAInfo.setValue(value, forKey: "pr" + String(productList) + "cc") }
                if product_key.lowercased().contains("prcd"){
                    let regex = try? NSRegularExpression(pattern: "[^0-9]", options: .caseInsensitive)
                    let textToNS = product_key as NSString
                    let chidx = regex?.stringByReplacingMatches(in: product_key, options: [], range: NSRange(location: 0, length: textToNS.length), withTemplate: "")
                    let  idx = (chidx! as NSString)
                    GAInfo.setValue(value, forKey: "pr" + String(productList) + "cd" + (idx as String))
                }
                if product_key.lowercased().contains("prme"){
                    let regex = try? NSRegularExpression(pattern: "[^0-9]", options: .caseInsensitive)
                    let textToNS = product_key as NSString
                    let chidx = regex?.stringByReplacingMatches(in: product_key, options: [], range: NSRange(location: 0, length: textToNS.length), withTemplate: "")
                    let  idx = (chidx! as NSString)
                    GAInfo.setValue(value, forKey: "pr" + String(productList) + "cm" + (idx as String))
                }
            }
        }
        productList += 1
    }
    return GAInfo
}

func GADataSend_Ecommerce(EcommerceStep: String,GAAction: Dictionary<String, String>, GAProduct: Dictionary<String, Dictionary<String, String>>, GAInfo: Dictionary<String, String>){
    do{
        var GAProduct = GAProduct
        var screenView_dict = NSMutableDictionary()

        for(key, value) in GAAction {
            if value.count > 0 {
                screenView_dict.setValue(value, forKey: key)
            }
        }
        for(key, value) in GAInfo {
            if value.count > 0 {
                screenView_dict.setValue(value, forKey: key)
            }
        }

        if EcommerceStep.lowercased() == "click"{
            screenView_dict.setValue("click", forKey: "pa")
        }
        if EcommerceStep.lowercased() == "detail"{
            screenView_dict.setValue("detail", forKey: "pa")
        }
        if EcommerceStep.lowercased() == "add"{
            screenView_dict.setValue("add", forKey: "pa")
        }
        if EcommerceStep.lowercased() == "remove"{
            screenView_dict.setValue("remove", forKey: "pa")
        }
        if EcommerceStep.lowercased() == "checkout"{
            screenView_dict.setValue("checkout", forKey: "pa")
        }
        if EcommerceStep.lowercased() == "purchase"{
            screenView_dict.setValue("purchase", forKey: "pa")
        }
        if EcommerceStep.lowercased() == "refund"{
            screenView_dict.setValue("refund", forKey: "pa")
        }

        screenView_dict = GA_Product(GAProduct: GAProduct, GAInfo: screenView_dict)
        screenView_dict.setValue("event", forKey: "t")

        gaThread(dict: screenView_dict as! Dictionary<String, String>)
    }catch{
        print("Got an error: \(error)")
    }
}
