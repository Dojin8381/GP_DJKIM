import Foundation

enum GACustomKey :CustomStringConvertible{
    case Dimension1; case Dimension2; case Dimension3; case Dimension4; case Dimension5;
    case Dimension6; case Dimension7; case Dimension8; case Dimension9; case Dimension10;
    case Dimension11 ;case Dimension12; case Dimension13; case Dimension14; case Dimension15;
    case Dimension16; case Dimension17; case Dimension18; case Dimension19; case Dimension20;
    case Dimension21; case Dimension22; case Dimension23; case Dimension24; case Dimension25;
    case Dimension26; case Dimension27; case Dimension28; case Dimension29; case Dimension30;
    case Dimension31 ;case Dimension32; case Dimension33; case Dimension34; case Dimension35;
    case Dimension36; case Dimension37; case Dimension38; case Dimension39; case Dimension40;
    case Dimension41 ;case Dimension42; case Dimension43; case Dimension44; case Dimension45;
    case Dimension46; case Dimension47; case Dimension48; case Dimension49; case Dimension50;
    case Metric1; case Metric2; case Metric3; case Metric4; case Metric5;
    case Metric6; case Metric7; case Metric8; case Metric9; case Metric10;
    case Metric11; case Metric12; case Metric13; case Metric14; case Metric15;
    case Metric16; case Metric17; case Metric18; case Metric19; case Metric20;
    var description:String {
        switch self {
        case .Dimension1: return "dimension1" case .Dimension2: return "dimension2"
        case .Dimension3: return "dimension3" case .Dimension4: return "dimension4"
        case .Dimension5: return "dimension5" case .Dimension6: return "dimension6"
        case .Dimension7: return "dimension7" case .Dimension8: return "dimension8"
        case .Dimension9: return "dimension9" case .Dimension10: return "dimension10"
        case .Dimension11: return "dimension11" case .Dimension12: return "dimension12"
        case .Dimension13: return "dimension13" case .Dimension14: return "dimension14"
        case .Dimension15: return "dimension15" case .Dimension16: return "dimension16"
        case .Dimension17: return "dimension17" case .Dimension18: return "dimension18"
        case .Dimension19: return "dimension19" case .Dimension20: return "dimension20"
        case .Dimension21: return "dimension21" case .Dimension22: return "dimension22"
        case .Dimension23: return "dimension23" case .Dimension24: return "dimension24"
        case .Dimension25: return "dimension25" case .Dimension26: return "dimension26"
        case .Dimension27: return "dimension27" case .Dimension28: return "dimension28"
        case .Dimension29: return "dimension29" case .Dimension30: return "dimension30"
        case .Dimension31: return "dimension31" case .Dimension32: return "dimension32"
        case .Dimension33: return "dimension33" case .Dimension34: return "dimension34"
        case .Dimension35: return "dimension35" case .Dimension36: return "dimension36"
        case .Dimension37: return "dimension37" case .Dimension38: return "dimension38"
        case .Dimension39: return "dimension39" case .Dimension40: return "dimension40"
        case .Dimension41: return "dimension41" case .Dimension42: return "dimension42"
        case .Dimension43: return "dimension43" case .Dimension44: return "dimension44"
        case .Dimension45: return "dimension45" case .Dimension46: return "dimension46"
        case .Dimension47: return "dimension47" case .Dimension48: return "dimension48"
        case .Dimension49: return "dimension49" case .Dimension50: return "dimension50"
        case .Metric1: return "metric1" case .Metric2: return "metric2"
        case .Metric3: return "metric3" case .Metric4: return "metric4"
        case .Metric5: return "metric5" case .Metric6: return "metric6"
        case .Metric7: return "metric7" case .Metric8: return "metric8"
        case .Metric9: return "metric9" case .Metric10: return "metric10"
        case .Metric11: return "metric11" case .Metric12: return "metric12"
        case .Metric13: return "metric13" case .Metric14: return "metric14"
        case .Metric15: return "metric15" case .Metric16: return "metric16"
        case .Metric17: return "metric17" case .Metric18: return "metric18"
        case .Metric19: return "metric19" case .Metric20: return "metric20"
        }
    }
}

enum GAHitKey :CustomStringConvertible{
    case UserID;
    case CampaignUrl;
    case Title;
    case EventCategory;
    case EventAction;
    case EventLabel;
    case EventValue;
    case NonInteraction;
    case PromotionID;
    case PromotionName;
    case PromotionCreative;
    case PromotionPosition;
    case CurrencyCode;
    var description:String{
        switch self {
        case .UserID: return "uid"
        case .CampaignUrl: return "camp_url"
        case .Title: return "title"
        case .EventCategory: return "category"
        case .EventAction: return "action"
        case .EventLabel: return "label"
        case .EventValue: return "value"
        case .NonInteraction: return "ni"
        case .PromotionID: return "promo_id"
        case .PromotionName: return "promo_nm"
        case .PromotionCreative: return "promo_cr"
        case .PromotionPosition: return "promo_ps"
        case .CurrencyCode : return "cu"
        }
    }
}
enum GAEcommerceStepKey:CustomStringConvertible{
    case Impression;
    case Detail;
    case Click;
    case Add;
    case Remove;
    case Checkout;
    case Purchase;
    case Refund;
    case PromotionImpression;
    case PromotionClick;
    var description: String{
        switch self {
        case .Impression: return "impression"
        case .Click: return "click"
        case .Detail: return "detail"
        case .Add: return "add"
        case .Remove: return "remove"
        case .Checkout: return "checkout"
        case .Purchase: return "purchase"
        case .Refund: return "refund"
        case .PromotionImpression: return "promotionimpression"
        case .PromotionClick: return "promotionclick"
        }
    }
}

enum GAActionFieldKey:CustomStringConvertible{
    case TransactionID;
    case TransactionRevenue;
    case TransactionTax;
    case TransactionShipping;
    case TransactionCouponCode
    case TransactionAffiliation;
    case ProductActionList;
    case CheckoutStep;
    case CheckoutOptions;
    var description: String{
        switch self {
        case .TransactionID: return "af_id"
        case .TransactionRevenue: return "af_revenue"
        case .TransactionTax: return "af_tax"
        case .TransactionShipping: return "af_shipping"
        case .TransactionCouponCode: return "af_coupon"
        case .TransactionAffiliation: return "af_affliation"
        case .ProductActionList: return "af_list"
        case .CheckoutStep: return "af_step"
        case .CheckoutOptions: return "af_option"
        }
    }
}
enum GAProductKey:CustomStringConvertible{
    case ProductID;
    case ProductName;
    case ProductBrand;
    case ProductCategory;
    case ProductVariant;
    case ProductPrice;
    case ProductQuantity;
    case ProductCouponCode;
    case ProductPosition;
    case ImpressionList;
    case ProductDimension1; case ProductDimension2; case ProductDimension3; case ProductDimension4; case ProductDimension5;
    case ProductDimension6; case ProductDimension7; case ProductDimension8; case ProductDimension9; case ProductDimension10;
    case ProductDimension11; case ProductDimension12; case ProductDimension13; case ProductDimension14; case ProductDimension15;
    case ProductDimension16; case ProductDimension17; case ProductDimension18; case ProductDimension19; case ProductDimension20;
    case ProductMetric1; case ProductMetric2; case ProductMetric3; case ProductMetric4; case ProductMetric5;
    case ProductMetric6; case ProductMetric7; case ProductMetric8; case ProductMetric9; case ProductMetric10;
    case ProductMetric11; case ProductMetric12; case ProductMetric13; case ProductMetric14; case ProductMetric15;
    case ProductMetric16; case ProductMetric17; case ProductMetric18; case ProductMetric19; case ProductMetric20;
    var description: String{
        switch self {
        case .ProductID: return "prid"
        case .ProductName: return "prnm"
        case .ProductBrand: return "prbr"
        case .ProductCategory: return "prca"
        case .ProductVariant: return "prva"
        case .ProductPrice: return "prpr"
        case .ProductQuantity: return "prqt"
        case .ProductCouponCode: return "prcc"
        case .ProductPosition: return "prps"
        case .ImpressionList: return "prlist"
        case .ProductDimension1: return "prcd1" case .ProductDimension2: return "prcd2"
        case .ProductDimension3: return "prcd3" case .ProductDimension4: return "prcd4"
        case .ProductDimension5: return "prcd5" case .ProductDimension6: return "prcd6"
        case .ProductDimension7: return "prcd7" case .ProductDimension8: return "prcd8"
        case .ProductDimension9: return "prcd9" case .ProductDimension10: return "prcd10"
        case .ProductDimension11: return "prcd11" case .ProductDimension12: return "prcd12"
        case .ProductDimension13: return "prcd13" case .ProductDimension14: return "prcd14"
        case .ProductDimension15: return "prcd15" case .ProductDimension16: return "prcd16"
        case .ProductDimension17: return "prcd17" case .ProductDimension18: return "prcd18"
        case .ProductDimension19: return "prcd19" case .ProductDimension20: return "prcd20"
        case .ProductMetric1: return "prme1" case .ProductMetric2: return "prme2"
        case .ProductMetric3: return "prme3" case .ProductMetric4: return "prme4"
        case .ProductMetric5: return "prme5" case .ProductMetric6: return "prme6"
        case .ProductMetric7: return "prme7" case .ProductMetric8: return "prme8"
        case .ProductMetric9: return "prme9"case .ProductMetric10: return "prme10"
        case .ProductMetric11: return "prme11"case .ProductMetric12: return "prme12"
        case .ProductMetric13: return "prme13"case .ProductMetric14: return "prme14"
        case .ProductMetric15: return "prme15"case .ProductMetric16: return "prme16"
        case .ProductMetric17: return "prme17"case .ProductMetric18: return "prme18"
        case .ProductMetric19: return "prme19"case .ProductMetric20: return "prme20"
        }
    }
}
func GAData_Nilset(dict: Dictionary<String, String>){
    var mTracker = GAI.sharedInstance()?.defaultTracker
    for (key, value) in dict{
        if key.lowercased().contains("dimension"){
            let regex = try? NSRegularExpression(pattern: "[^0-9]", options: .caseInsensitive)
            let textToNS = key as NSString
            let chidx = regex?.stringByReplacingMatches(in: key, options: [], range: NSRange(location: 0, length: textToNS.length), withTemplate: "")
            let  idx = (chidx as! NSString).integerValue
            mTracker?.set(GAIFields .customDimension(for: UInt(idx)), value: nil)
        }
        if key.lowercased().contains("metric"){
            let regex = try? NSRegularExpression(pattern: "[^0-9]", options: .caseInsensitive)
            let textToNS = key as NSString
            let chidx = regex?.stringByReplacingMatches(in: key, options: [], range: NSRange(location: 0, length: textToNS.length), withTemplate: "")
            let  idx = (chidx as! NSString).integerValue
            mTracker?.set(GAIFields .customMetric(for: UInt(idx)), value: nil)
        }
    }
    mTracker?.set(kGAIScreenName, value: nil)
    mTracker?.set(kGAIUserId, value: nil)
    mTracker?.set(kGAICurrencyCode, value:nil)
}

func GADataSend_Screen(GAInfo : Dictionary<String, String>){
    do{
        var mTracker = GAI.sharedInstance()?.defaultTracker
        mTracker?.set(kGAIHitType, value: "screenview")
        var eventBuilder = GAIDictionaryBuilder.init()
        for  (key, value) in GAInfo {
            if  value != nil && value.count > 0{
                if key.lowercased().contains("dimension"){
                    let regex = try? NSRegularExpression(pattern: "[^0-9]", options: .caseInsensitive)
                    let textToNS = key as NSString
                    let chidx = regex?.stringByReplacingMatches(in: key, options: [], range: NSRange(location: 0, length: textToNS.length), withTemplate: "")
                    let  idx = (chidx as! NSString).integerValue
                    mTracker?.set(GAIFields .customDimension(for: UInt(idx)), value: value)
                }
                if key.lowercased().contains("metric"){
                    let regex = try? NSRegularExpression (pattern: "[^0-9]", options: .caseInsensitive)
                    let textToNS = key as NSString
                    let chidx = regex?.stringByReplacingMatches(in: key, options: [], range: NSRange(location: 0, length: textToNS.length), withTemplate: "")
                    let  idx = (chidx as! NSString).integerValue
                    mTracker?.set(GAIFields .customMetric(for: UInt(idx)), value: value)
                }
                if key.lowercased() == ("uid"){ mTracker?.set(kGAIUserId, value: value) }
                if key.lowercased() == ("title"){ mTracker?.set(kGAIScreenName, value: value) }
                if key.lowercased() == ("camp_url"){ eventBuilder.setCampaignParametersFromUrl(value) }
                if key.lowercased() == ("ni") && value == "1" { eventBuilder.set(value, forKey: kGAINonInteraction) }
            }
        }
        var hitParamsDic = eventBuilder.build()
        guard let builder = GAIDictionaryBuilder.createScreenView() else{ return }
        mTracker?.send(builder.setAll(hitParamsDic as![NSObject:AnyObject]).build() as [NSObject:AnyObject])
        GAData_Nilset(dict: GAInfo)
    }catch{
        print("Got an error: \(error)")
    }
}

func GADataSend_Event(GAInfo : Dictionary<String,String>) -> Void {
    do{
        var category:String? = nil
        var action:String? = nil
        var label:String? = nil
        var event_value:String? = nil
        var mTracker = GAI.sharedInstance()?.defaultTracker
        mTracker?.set(kGAIHitType, value: "event")
        var eventBuilder = GAIDictionaryBuilder.init()
        for (key, value) in GAInfo{
            if  value != nil && value.count > 0{
                if key.lowercased().contains("dimension"){
                    let regex = try? NSRegularExpression(pattern: "[^0-9]", options: .caseInsensitive)
                    let textToNS = key as NSString
                    let chidx = regex?.stringByReplacingMatches(in: key, options: [], range: NSRange(location: 0, length: textToNS.length), withTemplate: "")
                    let  idx = (chidx as! NSString).integerValue
                    mTracker?.set(GAIFields .customDimension(for: UInt(idx)), value: value)
                }
                if key.lowercased().contains("metric"){
                    let regex = try? NSRegularExpression (pattern: "[^0-9]", options: .caseInsensitive)
                    let textToNS = key as NSString
                    let chidx = regex?.stringByReplacingMatches(in: key, options: [], range: NSRange(location: 0, length: textToNS.length), withTemplate: "")
                    let  idx = (chidx as! NSString).integerValue
                    mTracker?.set(GAIFields .customMetric(for: UInt(idx)), value: value)
                }
                if key.lowercased() == ("uid"){ mTracker?.set(kGAIUserId, value: value) }
                if key.lowercased() == ("title"){ mTracker?.set(kGAIScreenName, value: value) }
                if key.lowercased() == ("camp_url"){ eventBuilder.setCampaignParametersFromUrl(value) }
                if key.lowercased() == ("ni") && value == "1" { eventBuilder.set(value, forKey: kGAINonInteraction) }
                if key.lowercased() == ("category"){ category = value }
                if key.lowercased() == ("action"){ action = String(value) }
                if key.lowercased() == ("label"){ label = String(value) }
                if key.lowercased() == ("value"){ event_value = String(value) }
            }
        }
        var hitParamsDict = eventBuilder.build()
        guard let builder = GAIDictionaryBuilder.createEvent(withCategory: category, action: action, label: label, value:(event_value != nil) ? Int(event_value as! String)! as NSNumber : nil ) else { return }
        mTracker?.send(builder.setAll(hitParamsDict as![NSObject:AnyObject]).build() as [NSObject:AnyObject])
        GAData_Nilset(dict: GAInfo)
    }catch{
        print("Got an error: \(error)")
    }
}

func GA_Product(EcommerceStep: String, GAProduct: Dictionary<String, Dictionary<String,String>>, ecommerceBuilder: GAIDictionaryBuilder) -> GAIDictionaryBuilder{
    do{
        var productList = ""
        for (keys, value) in GAProduct{
            let product = GAIEcommerceProduct()
            if keys.lowercased().contains("pr"){
                var ProductInfo = GAProduct[keys]
                for (product_key, value) in ProductInfo!{
                    if product_key.lowercased() == ("prid"){ product.setId(value) }
                    if product_key.lowercased() == ("prnm"){ product.setName(value) }
                    if product_key.lowercased() == ("prbr"){ product.setBrand(value) }
                    if product_key.lowercased() == ("prca"){ product.setCategory(value) }
                    if product_key.lowercased() == ("prva"){ product.setVariant(value) }
                    if product_key.lowercased() == ("prpr"){ product.setPrice(((Int(value as String)! as NSNumber))) }
                    if product_key.lowercased() == ("prqt"){ product.setQuantity(((Int(value as String)!  as NSNumber))) }
                    if product_key.lowercased() == ("prcc"){ product.setCouponCode(value) }
                    if product_key.lowercased() == ("prps"){ product.setPosition(((Int(value as String)!  as NSNumber))) }
                    if product_key.lowercased() == ("prlist"){ productList = value; }
                    if product_key.lowercased().contains("prcd"){
                        let regex = try? NSRegularExpression(pattern: "[^0-9]", options: .caseInsensitive)
                        let textToNS = product_key as NSString
                        let chidx = regex?.stringByReplacingMatches(in: product_key, options: [], range: NSRange(location: 0, length: textToNS.length), withTemplate: "")
                        let  idx = (chidx! as NSString).integerValue
                        product.setCustomDimension(UInt(idx), value: value)
                    }
                    if product_key.lowercased().contains("prme"){
                        let regex = try? NSRegularExpression(pattern: "[^0-9]", options: .caseInsensitive)
                        let textToNS = product_key as NSString
                        let chidx = regex?.stringByReplacingMatches(in: product_key, options: [], range: NSRange(location: 0, length: textToNS.length), withTemplate: "")
                        let  idx = (chidx! as NSString).integerValue
                        product.setCustomMetric(UInt(idx), value: (Int(value as String)!  as NSNumber))
                    }
                }
            }
            if EcommerceStep.lowercased() != "impression"{ ecommerceBuilder.add(product) }
            else{ ecommerceBuilder.addProductImpression(product, impressionList: productList, impressionSource: "impressionSource") }
        }
        return ecommerceBuilder
    }catch{
        print("Got an error: \(error)")
    }
}

func GA_ActionField(GAAction: Dictionary<String,String>, productAction: GAIEcommerceProductAction) -> GAIEcommerceProductAction{
    do{
        for (actionField_key,value) in GAAction{
            if actionField_key.lowercased() == "af_id"{ productAction.setTransactionId(value) }
            if actionField_key.lowercased() == "af_revenue"{ productAction.setRevenue(((Int(value as String)!  as NSNumber))) }
            if actionField_key.lowercased() == "af_tax"{ productAction.setTax(((Int(value as String)!  as NSNumber))) }
            if actionField_key.lowercased() == "af_shipping"{ productAction.setShipping(((Int(value as String)!  as NSNumber))) }
            if actionField_key.lowercased() == "af_coupon"{ productAction.setCouponCode(value) }
            if actionField_key.lowercased() == "af_affiliation"{ productAction.setAffiliation(value) }
            if actionField_key.lowercased() == "af_list"{ productAction.setProductActionList(value) }
            if actionField_key.lowercased() == "af_step"{ productAction.setCheckoutStep(((Int(value as String)!  as NSNumber))) }
            if actionField_key.lowercased() == "af_option"{ productAction.setCheckoutOption(value) }
        }
        return productAction
    }catch{
        print("Got an error: \(error)")
    }
}

func GADataSend_Ecommerce(EcommerceStep: String,GAAction: Dictionary<String, String>, GAProduct: Dictionary<String, Dictionary<String, String>>, GAInfo: Dictionary<String, String>){
    do{
        var GAProduct = GAProduct
        var category:String? = nil
        var action:String? = nil
        var label:String? = nil
        var event_value:String? = nil
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        var mTracker = GAI.sharedInstance()?.defaultTracker
        mTracker?.set(kGAIHitType, value: "event")
        var ecommerceBuilder = GAIDictionaryBuilder.init()
        var promotion = GAIEcommercePromotion.init()
        for (key, value) in GAInfo{
            if value != nil && value.count > 0{
                if key.lowercased().contains("dimension"){
                    let regex = try? NSRegularExpression(pattern: "[^0-9]", options: .caseInsensitive)
                    let textToNS = key as NSString
                    let chidx = regex?.stringByReplacingMatches(in: key, options: [], range: NSRange(location: 0, length: textToNS.length), withTemplate: "")
                    let  idx = (chidx as! NSString).integerValue
                    mTracker?.set(GAIFields .customDimension(for: UInt(idx)), value: value)
                }
                if key.lowercased().contains("metric"){
                    let regex = try? NSRegularExpression(pattern: "[^0-9]", options: .caseInsensitive)
                    let textToNS = key as NSString
                    let chidx = regex?.stringByReplacingMatches(in: key, options: [], range: NSRange(location: 0, length: textToNS.length), withTemplate: "")
                    let  idx = (chidx as! NSString).integerValue
                    mTracker?.set(GAIFields .customMetric(for: UInt(idx)), value: value)
                }
                if key.lowercased() == ("uid"){ mTracker?.set(kGAIUserId, value: value) }
                if key.lowercased() == ("title"){ mTracker?.set(kGAIScreenName, value: value) }
                if key.lowercased() == ("camp_url"){ ecommerceBuilder.setCampaignParametersFromUrl(value) }
                if key.lowercased() == ("cu"){ mTracker?.set(kGAICurrencyCode, value : value) }
                if key.lowercased() == ("category"){ category = value }
                if key.lowercased() == ("action"){ action = String(value) }
                if key.lowercased() == ("label"){ label = String(value) }
                if key.lowercased() == ("value"){ event_value = String(value) }
                if key.lowercased() == ("ni") && value == "1"{ ecommerceBuilder.set(value, forKey: kGAINonInteraction) }
            }
        }
        ecommerceBuilder = GAIDictionaryBuilder.createEvent(withCategory: category, action: action, label: label, value:(event_value != nil) ? Int(event_value as! String)! as NSNumber : nil )
        if EcommerceStep.lowercased() == "impression"{
            var productActionList:String = GAAction["af_list"]!
            for(key, value) in GAProduct{
                GAProduct[key]?["prlist"] = productActionList
            }
        }
        if EcommerceStep.lowercased() == "click"{
            var pa = GAIEcommerceProductAction();
            pa.setAction(kGAIPAClick)
            pa = GA_ActionField(GAAction: GAAction, productAction: pa)
            ecommerceBuilder.setProductAction(pa)
        }
        if EcommerceStep.lowercased() == "detail"{
            var pa = GAIEcommerceProductAction();
            pa.setAction(kGAIPADetail)
            pa = GA_ActionField(GAAction: GAAction, productAction: pa)
            ecommerceBuilder.setProductAction(pa)
        }
        if EcommerceStep.lowercased() == "add"{
            var pa = GAIEcommerceProductAction();
            pa.setAction(kGAIPAAdd)
            pa = GA_ActionField(GAAction: GAAction, productAction: pa)
            ecommerceBuilder.setProductAction(pa)
        }
        if EcommerceStep.lowercased() == "remove"{
            var pa = GAIEcommerceProductAction();
            pa.setAction(kGAIPARemove)
            pa = GA_ActionField(GAAction: GAAction, productAction: pa)
            ecommerceBuilder.setProductAction(pa)
        }
        if EcommerceStep.lowercased() == "checkout"{
            var pa = GAIEcommerceProductAction();
            pa.setAction(kGAIPACheckout)
            pa = GA_ActionField(GAAction: GAAction, productAction: pa)
            ecommerceBuilder.setProductAction(pa)
        }
        if EcommerceStep.lowercased() == "purchase"{
            var pa = GAIEcommerceProductAction();
            pa.setAction(kGAIPAPurchase)
            pa = GA_ActionField(GAAction: GAAction, productAction: pa)
            ecommerceBuilder.setProductAction(pa)
        }
        if EcommerceStep.lowercased() == "refund"{
            var pa = GAIEcommerceProductAction();
            pa.setAction(kGAIPARefund)
            pa = GA_ActionField(GAAction: GAAction, productAction: pa)
            ecommerceBuilder.setProductAction(pa)
        }
        if EcommerceStep.lowercased().contains("promotion"){
            for (key, value) in GAInfo{
                if value != nil && value.count > 0{
                    if key.lowercased() == "promo_id"{ promotion.setId(value) }
                    if key.lowercased() == "promo_nm"{ promotion.setName(value) }
                    if key.lowercased() == "promo_cr"{ promotion.setCreative(value) }
                    if key.lowercased() == "promo_ps"{ promotion.setPosition(value) }
                }
            }
            if EcommerceStep.lowercased() == "promotionclick" { ecommerceBuilder .set(kGAIPromotionClick, forKey: kGAIPromotionAction) }
            ecommerceBuilder.add(promotion)
        }else{ ecommerceBuilder = GA_Product(EcommerceStep: EcommerceStep, GAProduct: GAProduct, ecommerceBuilder: ecommerceBuilder) }
        let hitParamsDict = ecommerceBuilder.build()
        mTracker?.send(ecommerceBuilder.setAll(hitParamsDict! as[NSObject:AnyObject]).build() as[NSObject:AnyObject])
        GAData_Nilset(dict: GAInfo)
    }catch{
        print("Got an error: \(error)")
    }
}



