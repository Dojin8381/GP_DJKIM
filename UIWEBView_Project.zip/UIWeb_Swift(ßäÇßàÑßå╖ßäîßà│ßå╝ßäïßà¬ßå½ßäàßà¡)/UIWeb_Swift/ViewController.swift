//
//  ViewController.swift
//  UIWeb_Swift
//
//  Created by Goldenplanet on 08/08/2019.
//  Copyright © 2019 골든플래닛. All rights reserved.
//

import UIKit
import WebKit

class ViewController: UIViewController,UIWebViewDelegate,NSURLConnectionDelegate{
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let webView = UIWebView(frame : CGRect.init(x:0, y:0, width:400, height:900))
        let URL = "http://211.49.99.88:8011/alphalab/srkang"
        let url = NSURL(string:URL)
        let request = NSURLRequest(url: NSURL(string : URL)! as URL)
        webView.delegate = self
        webView.loadRequest(request as URLRequest)
        self.view.addSubview(webView)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func webView(_ webView: UIWebView, shouldStartLoadWith request: URLRequest, navigationType: UIWebViewNavigationType) -> Bool {
        let requestString = request
        if request.url?.absoluteString.hasPrefix("jscall://") == true{
            var mTracker = GAI.sharedInstance()?.defaultTracker
            var dimension = Dictionary<String,AnyObject>()
            var metric = Dictionary<String, AnyObject>()
            //let data = (message.body as AnyObject).data(using: String.Encoding.utf8.rawValue,allowLossyConversion: false)!
            let documentLoaction = requestString.url?.absoluteString.removingPercentEncoding
            let requestStrings = documentLoaction?.replacingOccurrences(of:"jscall://",with: "").replacingOccurrences(of: "\\", with: "")
            let data = requestStrings?.data(using: String.Encoding.utf8,allowLossyConversion: false)!
            do {
                let json = try JSONSerialization.jsonObject(with: data!, options: []) as! [String: AnyObject]
                let sType:String
                sType = json["type"] as! String
                if(json["title"] != nil){ mTracker?.set(kGAIScreenName, value: json["title"] as! String) }
                if(json["userId"] != nil) { mTracker?.set(kGAIUserId, value: json["userId"] as! String) }
                if(json["dimension"] != nil){
                    dimension = json["dimension"] as! [String : AnyObject]
                    if dimension != nil{
                        for (key,value) in dimension{
                            let regex = try? NSRegularExpression(pattern: "[^0-9]", options: .caseInsensitive)
                            let textToNS = key as NSString
                            let chidx = regex?.stringByReplacingMatches(in: key, options: [], range: NSRange(location: 0, length: textToNS.length), withTemplate: "")
                            let  idx = (chidx! as NSString).integerValue
                            mTracker?.set(GAIFields .customDimension(for: UInt(idx)), value: String(value as! String))
                        }
                    }
                }
                if(json["metric"] != nil){
                    metric = json["metric"] as! [String : AnyObject]
                    if metric != nil{
                        for (key,value) in metric{
                            var value = value
                            let regex = try? NSRegularExpression(pattern: "[^0-9]", options: .caseInsensitive)
                            let textToNS = key as NSString
                            let chidx = regex?.stringByReplacingMatches(in: key, options: [], range: NSRange(location: 0, length: textToNS.length), withTemplate: "")
                            let  idx = (chidx as! NSString).integerValue
                            mTracker?.set(GAIFields .customMetric(for: UInt(idx)), value: String(value as! Int))
                            value = String(value as! Int) as AnyObject
                            metric[key] = value
                        }
                    }
                }
                if(sType.lowercased().contains("p")){
                    let screenview_builder = GAIDictionaryBuilder.createScreenView()
                    mTracker?.send( screenview_builder?.build() as! [AnyHashable : Any])
                    GAData_Nilset(dict: dimension as! Dictionary<String, String>)
                    GAData_Nilset(dict: metric as! Dictionary<String, String>)
                } else {
                    var category:String! = nil
                    var action:String! = nil
                    var label:String! = nil
                    var productList:String! = nil
                    var event_builder = GAIDictionaryBuilder.init()
                    if(json["category"] != nil ){ category = json["category"] as! String }
                    if(json["action"] != nil ){ action = json["action"] as! String }
                    if(json["label"] != nil ){ label = json["label"] as! String }
                    
                    event_builder = GAIDictionaryBuilder.createEvent(withCategory: category, action: action, label: label, value: nil)
                    
                    if(json["ecommerce"] != nil){
                        var promotion_data = Array<Dictionary<String,AnyObject>>()
                        var action = GAIEcommerceProductAction()
                        var e_dict = Dictionary<String,AnyObject>()
                        var actionfield_dict:[String:AnyObject] = [:]
                        var product_dict = Array<Dictionary<String,AnyObject>>()
                        var productList:String
                        var Ecommerce_step:String
                        let ecommerce_data = json["ecommerce"] as! [String: AnyObject]
                        var ecommerce_sub_data:[String: AnyObject] = [:]
                        for(key, value) in ecommerce_data {
                            
                            Ecommerce_step = key
                            productList = ""
                            if key.lowercased().contains("currencycode"){ mTracker?.set(kGAICurrencyCode, value: json["currencyCode"] as? String)}
                            else {
                                ecommerce_sub_data = ecommerce_data[key] as! [String:AnyObject]
                                if key.lowercased().contains("impressions"){
                                    e_dict = ecommerce_data[key] as! [String: AnyObject]
                                    actionfield_dict = ecommerce_sub_data["actionField"] as! [String:AnyObject]
                                    productList = actionfield_dict["list"] as! String
                                }
                                for (key,value) in ecommerce_sub_data{
                                    if key.lowercased().contains("products"){
                                        product_dict = ecommerce_sub_data[key] as! Array<Dictionary<String,AnyObject>>
                                        event_builder = GAData_Products(product_dict: product_dict, EcommerceStep: Ecommerce_step, productList: productList, ecommerceBuilder: event_builder)
                                        
                                    }
                                    if key.lowercased().contains("actionfield"){
                                        actionfield_dict = ecommerce_sub_data[key] as! [String:AnyObject]
                                        action = GAData_Actionfield(actionField_dict: actionfield_dict, productAction: action)
                                        event_builder.setProductAction(action)
                                    }
                                }
                            }
                            if key.lowercased().contains("detail"){ action.setAction(kGAIPADetail) }
                            if key.lowercased().contains("click"){ action.setAction(kGAIPAClick) }
                            if key.lowercased().contains("add"){ action.setAction(kGAIPAAdd) }
                            if key.lowercased().contains("checkout"){ action.setAction(kGAIPACheckout)}
                            if key.lowercased().contains("purchase"){ action.setAction(kGAIPAPurchase) }
                            if key.lowercased().contains("remove"){ action.setAction(kGAIPARemove) }
                            if key.lowercased().contains("refund"){ action.setAction(kGAIPARefund)}
                            if key.lowercased().contains("promoview") {
                                var promotion_dict:[String: AnyObject] = [:]
                                //var ecommerce_sub_data:[String: AnyObject] = [:]
                                //ecommerce_sub_data = ecommerce_data[key] as! [String:AnyObject]
                                promotion_dict = ecommerce_data[key] as! [String: AnyObject]
                                for(key, value) in promotion_dict {
                                    promotion_data = promotion_dict[key] as! Array<Dictionary<String,AnyObject>>
                                    event_builder = GAData_Promotion(promotion_dict: promotion_data, EcommerceStep: Ecommerce_step, ecommerceBuilder: event_builder)
                                }
                            }
                            //if(json["currencyCode"] != nil){ mTracker?.set(kGAICurrencyCode, value: json["currencyCode"] as! String ) }
                            
                            if key.lowercased().contains("promoclick"){
                                var promotion_dict = Dictionary<String,AnyObject>()
                                promotion_dict = ecommerce_data[key] as! [String: AnyObject]
                                for(key, value) in promotion_dict{
                                    promotion_data = promotion_dict[key] as! Array<Dictionary<String,AnyObject>>
                                    event_builder = GAData_Promotion(promotion_dict: promotion_data, EcommerceStep: Ecommerce_step, ecommerceBuilder: event_builder)
                                }
                            }
                        }
                    }
                    mTracker?.send( event_builder.build() as! [AnyHashable : Any])
                    GAData_Nilset(dict: dimension as! Dictionary<String, String>)
                    GAData_Nilset(dict: metric as! Dictionary<String, String>)
                    return false
                }
            } catch let error as NSError {
                print("Failed to load: \(error.localizedDescription)")
            }
        }
        return true
    }
    func GAData_Promotion(promotion_dict:Array<Dictionary<String,AnyObject>>, EcommerceStep:String, ecommerceBuilder:GAIDictionaryBuilder) -> GAIDictionaryBuilder {
        for i in 0..<promotion_dict.count{
            var promotion = GAIEcommercePromotion()
            var dict = promotion_dict[i]
            for(key,value) in dict{
                if key.lowercased().contains("id"){ promotion.setId(value as? String) }
                if key.lowercased().contains("name"){ promotion.setName(value as? String) }
                if key.lowercased().contains("creative"){ promotion.setCreative(value as? String) }
                if key.lowercased().contains("position"){ promotion.setPosition(value as? String) }
            }
            if EcommerceStep != "promoclick"{ ecommerceBuilder.add(promotion) }
            else{
                ecommerceBuilder.set(kGAIPromotionClick, forKey: kGAIPromotionAction)
                ecommerceBuilder.add(promotion)
            }
        }
        return ecommerceBuilder
    }
    
    func GAData_Actionfield(actionField_dict:Dictionary<String,AnyObject>, productAction:GAIEcommerceProductAction) -> GAIEcommerceProductAction{
        do {
            for (key, value) in actionField_dict{
                if key.lowercased().contains("id"){ productAction.setTransactionId(value as? String) }
                if key.lowercased().contains("revenue"){ productAction.setRevenue(((Int(value as! String)! as NSNumber))) }
                if key.lowercased().contains("tax"){ productAction.setTax(((Int(value as! String)! as NSNumber))) }
                if key.lowercased().contains("shipping"){ productAction.setTax(((Int(value as! String)! as NSNumber))) }
                if key.lowercased().contains("coupon"){ productAction.setCouponCode(value as? String) }
                if key.lowercased().contains("affiliation"){ productAction.setAffiliation(value as? String) }
                if key.lowercased().contains("list"){ productAction.setProductActionList(value as? String) }
                if key.lowercased().contains("step"){ productAction.setCheckoutStep(((Int(value as! String)! as NSNumber))) }
                if key.lowercased().contains("option"){ productAction.setCheckoutOption(value as? String) }
            }
        } catch {
            print("Got an error: \(error)")
        }
        return productAction
    }
    func GAData_Products(product_dict:Array<Dictionary<String,AnyObject>>, EcommerceStep:String, productList:String, ecommerceBuilder:GAIDictionaryBuilder) -> GAIDictionaryBuilder{
        do {
            for i in 0..<product_dict.count{
                var products = GAIEcommerceProduct()
                var dict = product_dict[i]
                for(key,value) in dict{
                    if key.lowercased().contains("id"){ products.setId(value as? String) }
                    if key.lowercased().contains("name"){ products.setName(value as? String) }
                    if key.lowercased().contains("brand"){ products.setBrand(value as? String) }
                    if key.lowercased().contains("category"){ products.setCategory(value as? String) }
                    if key.lowercased().contains("price"){ products.setPrice(((Int(value as! String)! as NSNumber))) }
                    if key.lowercased().contains("quantity"){ products.setQuantity(((Int(value as! String)! as NSNumber))) }
                    if key.lowercased().contains("variant"){ products.setVariant(value as? String) }
                    if key.lowercased().contains("coupon"){ products.setCouponCode(value as? String) }
                    if key.lowercased().contains("position"){ products.setPosition(value as? NSNumber) }
                    if key.lowercased().contains("dimension"){
                        let regex = try? NSRegularExpression(pattern: "[^0-9]", options: .caseInsensitive)
                        let textToNS = key as NSString
                        let chidx = regex?.stringByReplacingMatches(in: key, options: [], range: NSRange(location: 0, length: textToNS.length), withTemplate: "")
                        let  idx = (chidx! as NSString).integerValue
                        products.setCustomDimension(UInt(idx), value: String(value as! String ))
                    }
                    if key.lowercased().contains("metric"){
                        let regex = try? NSRegularExpression(pattern: "[^0-9]", options: .caseInsensitive)
                        let textToNS = key as NSString
                        let chidx = regex?.stringByReplacingMatches(in: key, options: [], range: NSRange(location: 0, length: textToNS.length), withTemplate: "")
                        let  idx = (chidx! as NSString).integerValue
                        products.setCustomMetric(UInt(idx), value: UInt(value as! NSNumber) as NSNumber)
                    }
                }
                if EcommerceStep != "impressions"{ ecommerceBuilder.add(products) }
                else { ecommerceBuilder.addProductImpression(products, impressionList: productList, impressionSource: "impressionSource") }
            }
        } catch {
            print("Got an error: \(error)")
        }
        return ecommerceBuilder
    }

}

