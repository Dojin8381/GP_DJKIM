//
//  GoogleAnalyticsBuilder.m
//  REAL_UIWEB
//
//  Created by Goldenplanet on 06/08/2019.
//  Copyright © 2019 Goldenplanet. All rights reserved.
//

#import "GoogleAnalyticsBuilder.h"


NSString *GACustomKey(UIImageOrientation input) {
    NSArray *arr = @[ @"dimension1",@"dimension2",@"dimension3",@"dimension4",@"dimension5",@"dimension6",@"dimension7",@"dimension8",@"dimension9",@"dimension10",@"dimension11",@"dimension12",@"dimension13",@"dimension14",@"dimension15",@"dimension16",@"dimension17",@"dimension18",@"dimension19",@"dimension20",@"dimension21",@"dimension22",@"dimension23",@"dimension24",@"dimension25",@"dimension26",@"dimension27",@"dimension28",@"dimension29",@"dimension30",@"dimension31",@"dimension32",@"dimension33",@"dimension34",@"dimension35",@"dimension36",@"dimension37",@"dimension38",@"dimension39",@"dimension40",@"dimension41",@"dimension42",@"dimension43",@"dimension44",@"dimension45",@"dimension46",@"dimension47",@"dimension48",@"dimension49",@"dimension50" ,@"metric1",@"metric2",@"metric3",@"metric4",@"metric5",@"metric6",@"metric7",@"metric8",@"metric9",@"metric10",@"metric11",@"metric12",@"metric13",@"metric14",@"metric15",@"metric16",@"metric17",@"metric18",@"metric19",@"metric20",@"metric21",@"metric22",@"metric23",@"metric23",@"metric25",@"metric26",@"metric27",@"metric28",@"metric29",@"metric30",@"metric31",@"metric32",@"metric33",@"metric34",@"metric35",@"metric36",@"metric37",@"metric38",@"metric39",@"metric40",@"metric41",@"metric42",@"metric43",@"metric44",@"metric45",@"metric46",@"metric47",@"metric48",@"metric49",@"metric50"
                      ];
    return (NSString *)[arr objectAtIndex:input];
}
NSString *GAHitKey(UIImageOrientation input) {
    NSArray *arr = @[
                     @"uid",
                     @"camp_url",
                     @"title",
                     @"category",
                     @"action",
                     @"label",
                     @"value",
                     @"ni",
                     @"promo_id",
                     @"promo_nm",
                     @"promo_cr",
                     @"promo_ps",
                     @"cu"
                     ];
    return (NSString *)[arr objectAtIndex:input];
}
NSString *GAEcommerceStepKey(UIImageOrientation input) {
    NSArray *arr = @[
                     @"impression",
                     @"detail",
                     @"click",
                     @"add",
                     @"remove",
                     @"checkout",
                     @"purchase",
                     @"refund",
                     @"promotionimpression",
                     @"promotionclick"
                     ];
    return (NSString *)[arr objectAtIndex:input];
}
NSString *GAActionFieldKey(UIImageOrientation input) {
    NSArray *arr = @[
                     @"af_id",
                     @"af_revenue",
                     @"af_tax",
                     @"af_shipping",
                     @"af_coupon",
                     @"af_affiliation",
                     @"af_list",
                     @"af_step",
                     @"af_option"
                     ];
    return (NSString *)[arr objectAtIndex:input];
}
NSString *GAProductKey(UIImageOrientation input) {
    NSArray *arr = @[
                     @"prid",
                     @"prnm",
                     @"prbr",
                     @"prca",
                     @"prva",
                     @"prpr",
                     @"prqt",
                     @"prcc",
                     @"prps",
                     @"prlist",
                     @"prcd1",@"prcd2",@"prcd3",@"prcd4",@"prcd5",@"prcd6",@"prcd7",@"prcd8",@"prcd9",@"prcd10",
                     @"prcd11",@"prcd12",@"prcd13",@"prcd14",@"prcd15",@"prcd16",@"prcd17",@"prcd18",@"prcd19",@"prcd20",
                     @"prme1",@"prme2",@"prme3",@"prme4",@"prme5",@"prme6",@"prme7",@"prme8",@"prme9",@"prme10",
                     @"prme11",@"prme12",@"prme13",@"prme14",@"prme15",@"prme16",@"prme17",@"prme18",@"prme19",@"prme20"
                     ];
    return (NSString *)[arr objectAtIndex:input];
}

void *GAData_Nilset(NSMutableDictionary *dict){
    @try {
        id<GAITracker> mTracker = [[GAI sharedInstance] defaultTracker];
        NSError* error;
        for(NSString *key in dict){
            NSString *value = [dict valueForKey:key];
            if([key containsString:@"dimension"]){
                NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"[^0-9]" options:NSRegularExpressionCaseInsensitive  error:&error];
                NSString *idx = [regex stringByReplacingMatchesInString:key options:0 range:NSMakeRange(0, [key length]) withTemplate:@""];
                [mTracker set:[GAIFields customDimensionForIndex:[idx integerValue]] value:nil];
            }
            if([key containsString:@"metric"]){
                NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"[^0-9]" options:NSRegularExpressionCaseInsensitive  error:&error];
                NSString *idx = [regex stringByReplacingMatchesInString:key options:0 range:NSMakeRange(0, [key length]) withTemplate:@""];
                [mTracker set:[GAIFields customMetricForIndex:[idx integerValue]] value:nil];
            }
        }
        [mTracker set:kGAIScreenName value:nil];
        [mTracker set:kGAIUserId value:nil];
        [mTracker set:kGAICurrencyCode value:nil];
    }
    @catch (NSException *e) {
        NSLog(@"Exception: %@", e);
    }
    
    return true;
}

void *GADataSend_Screen(NSMutableDictionary *GAInfo){
    NSError* error;
    id<GAITracker> mTracker = [[GAI sharedInstance] defaultTracker];
    [mTracker set:kGAIHitType value:@"screenview"];
    GAIDictionaryBuilder *eventBuilder = [[GAIDictionaryBuilder alloc]init];
    for(NSString *key in GAInfo){
        NSString *value = [GAInfo valueForKey:key];
        if(value != nil && [value length] >0 ){
            if([key.lowercaseString containsString:@"dimension"]){
                NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"[^0-9]" options:NSRegularExpressionCaseInsensitive  error:&error];
                NSString *idx = [regex stringByReplacingMatchesInString:key options:0 range:NSMakeRange(0, [key length]) withTemplate:@""];
                [mTracker set:[GAIFields customDimensionForIndex:[idx integerValue]] value:value];
            }
            if([key.lowercaseString isEqual:@"uid"]){ [mTracker set:kGAIUserId  value:value]; }
            if([key.lowercaseString isEqual:@"title"]){ [mTracker set:kGAIScreenName value:value]; }
            if([key.lowercaseString isEqual:@"camp_url"]){
                NSString *url = [(NSURL *) value absoluteString] ;
                [eventBuilder setCampaignParametersFromUrl:url];
            }
            if([key.lowercaseString isEqual:@"ni"] && [[GAInfo valueForKey:key]  isEqual:@"1"]){
                [eventBuilder set:value forKey:kGAINonInteraction];
            }
        }
    }
    NSDictionary *hitParamsDict = [eventBuilder build];
    [mTracker send:[[[GAIDictionaryBuilder createScreenView] setAll:hitParamsDict] build]];
    [mTracker set:kGAIScreenName value:nil];
    [mTracker set:kGAIUserId value:nil];
    GAData_Nilset(GAInfo);
    return true;
}

void *GADataSend_Event(NSMutableDictionary *GAInfo){
    NSError* error;
    NSString *category;
    NSString *action;
    NSString *label;
    NSString *event_value;
    id<GAITracker> mTracker = [[GAI sharedInstance] defaultTracker];
    [mTracker set:kGAIHitType value:@"event"];
    GAIDictionaryBuilder *eventBuilder = [[GAIDictionaryBuilder alloc] init];
    for(NSString *key in GAInfo){
        NSString *value = [GAInfo valueForKey:key];
        if(value != nil && [value length] >0 ){
            if([key.lowercaseString containsString:@"dimension"]){
                NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"[^0-9]" options:NSRegularExpressionCaseInsensitive  error:&error];
                NSString *idx = [regex stringByReplacingMatchesInString:key options:0 range:NSMakeRange(0, [key length]) withTemplate:@""];
                [mTracker set:[GAIFields customDimensionForIndex:[idx integerValue]] value:value];
            }
            if([key.lowercaseString containsString:@"metric"]){
                NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"[^0-9]" options:NSRegularExpressionCaseInsensitive  error:&error];
                NSString *idx = [regex stringByReplacingMatchesInString:key options:0 range:NSMakeRange(0, [key length]) withTemplate:@""];
                [mTracker set:[GAIFields customMetricForIndex:[idx integerValue]] value:value];
            }
            if([key.lowercaseString isEqual:@"uid"]){ [mTracker set:kGAIUserId  value:value]; }
            if([key.lowercaseString isEqual:@"title"]){ [mTracker set:kGAIScreenName value:value]; }
            if([key.lowercaseString isEqual:@"camp_url"]){
                NSString *url = [(NSURL *) value absoluteString] ;
                [eventBuilder setCampaignParametersFromUrl:url];
            }
            if([key.lowercaseString isEqual:@"category"]){ category = value; }
            if([key.lowercaseString isEqual:@"action"]){ action = value; }
            if([key.lowercaseString isEqual:@"label"]){ label = value; }
            if([key.lowercaseString isEqual:@"value"]){ event_value = value;}
            if([key.lowercaseString isEqual:@"ni"] && [[GAInfo valueForKey:key]  isEqual:@"1"]){
                [eventBuilder set:@"1" forKey:kGAINonInteraction];
            }
        }
    }
    NSDictionary *hitParams = [eventBuilder build];
    [mTracker send:[[[GAIDictionaryBuilder createEventWithCategory:category action:action label:label value:[event_value intValue] != nil ?@([event_value intValue]): nil ] setAll:hitParams] build] ];
    [mTracker set:kGAIScreenName value:nil];
    [mTracker set:kGAIUserId value:nil];
    GAData_Nilset(GAInfo);
    return true;
}

GAIDictionaryBuilder *GA_Product(NSString *EcommerceStep ,NSMutableDictionary *GAProduct, GAIDictionaryBuilder *ecommerceBuilder){
    NSError* error;
    NSString *productList ;
    for(NSString *keys in GAProduct){
        GAIEcommerceProduct *product = [[GAIEcommerceProduct alloc] init];;
        if([keys.lowercaseString containsString:@"pr"]){
            NSMutableDictionary *ProductInfo = [GAProduct valueForKey:keys];
            for(NSString *product_key in ProductInfo){
                NSString *value = [ProductInfo valueForKey:product_key];
                if([product_key.lowercaseString isEqual:@"prid"]){ [product setId:value]; }
                if([product_key.lowercaseString isEqual:@"prnm"]){ [product setName:value]; }
                if([product_key.lowercaseString isEqual:@"prbr"]){ [product setBrand:value]; }
                if([product_key.lowercaseString isEqual:@"prca"]){ [product setCategory:value]; }
                if([product_key.lowercaseString isEqual:@"prva"]){ [product setVariant:value]; }
                if([product_key.lowercaseString isEqual:@"prpr"]){ [product setPrice:@([value intValue])]; }
                if([product_key.lowercaseString isEqual:@"prqt"]){ [product setQuantity:@([value intValue])]; }
                if([product_key.lowercaseString isEqual:@"prcc"]){ [product setCouponCode:value]; }
                if([product_key.lowercaseString isEqual:@"prps"]){ [product setPosition:@([value intValue])]; }
                if([product_key.lowercaseString isEqual:@"prlist"]){ productList = value; }
                if([product_key.lowercaseString containsString:@"prcd"]){
                    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"[^0-9]" options:NSRegularExpressionCaseInsensitive error:&error];
                    NSString *idx = [regex stringByReplacingMatchesInString:product_key options:0 range:NSMakeRange(0, [product_key length]) withTemplate:@""];
                    [product setCustomDimension:[idx integerValue] value:value];
                }
                if([product_key.lowercaseString containsString:@"prme"]){
                    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"[^0-9]" options:NSRegularExpressionCaseInsensitive error:&error];
                    NSString *idx = [regex stringByReplacingMatchesInString:product_key options:0 range:NSMakeRange(0, [product_key length]) withTemplate:@""];
                    [product setCustomMetric:[idx integerValue] value:[NSNumber numberWithInt:[value intValue]]];
                }
            }
        }
        if(![EcommerceStep.lowercaseString isEqualToString:@"impression"]){
            [ecommerceBuilder addProduct:product];
        }
        else{
            [ecommerceBuilder addProductImpression:product impressionList:productList impressionSource:@"impressionSource"];
        }
    }
    return ecommerceBuilder;
}

GAIEcommerceProductAction *GA_ActionField(NSMutableDictionary *GAAction, GAIEcommerceProductAction *productAction){
    for(NSString *actionField_key in GAAction){
        NSString *value = [GAAction valueForKey:actionField_key];
        
        if([actionField_key.lowercaseString isEqual:@"af_id"]){ [productAction setTransactionId:value]; }
        if([actionField_key.lowercaseString isEqual:@"af_revenue"]){ [productAction setRevenue:@([value intValue])];}
        if([actionField_key.lowercaseString isEqual:@"af_tax"]){ [productAction setTax:@([value intValue])]; }
        if([actionField_key.lowercaseString isEqual:@"af_shipping"]){ [productAction setShipping:@([value intValue])]; }
        if([actionField_key.lowercaseString isEqual:@"af_coupon"]){ [productAction setCouponCode:value]; }
        if([actionField_key.lowercaseString isEqual:@"af_affiliation"]){ [productAction setAffiliation:value];}
        if([actionField_key.lowercaseString isEqual:@"af_list"]){[productAction setProductActionList:value];}
        if([actionField_key.lowercaseString isEqual:@"af_step"]){[productAction setCheckoutStep:@([value intValue])];}
        if([actionField_key.lowercaseString isEqual:@"af_option"]){ [productAction setCheckoutOption:value];}
    }
    return productAction;
}

void *GADataSend_Ecommerce(NSString *EcommerceStep, NSMutableDictionary *GAAction, NSMutableDictionary *GAProduct, NSMutableDictionary *GAInfo ){
    NSError* error;
    NSString *category;
    NSString *action;
    NSString *label;
    NSString *event_value;
    id<GAITracker> mTracker = [[GAI sharedInstance] defaultTracker];
    [mTracker set:kGAIHitType value:@"event"];
    GAIDictionaryBuilder *ecommerceBuilder = [[GAIDictionaryBuilder alloc]init];
    GAIEcommercePromotion *promotion = [[GAIEcommercePromotion alloc]init];
    for(NSString *key in GAInfo){
        NSString *value = [GAInfo valueForKey:key];
        if(value != nil && [value length] >0 ){
            if([key.lowercaseString containsString:@"dimension"]){
                NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"[^0-9]" options:NSRegularExpressionCaseInsensitive  error:&error];
                NSString *idx = [regex stringByReplacingMatchesInString:key options:0 range:NSMakeRange(0, [key length]) withTemplate:@""];
                [mTracker set:[GAIFields customDimensionForIndex:[idx integerValue]] value:value];
            }
            if([key.lowercaseString containsString:@"metric"]){
                NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"[^0-9]" options:NSRegularExpressionCaseInsensitive  error:&error];
                NSString *idx = [regex stringByReplacingMatchesInString:key options:0 range:NSMakeRange(0, [key length]) withTemplate:@""];
                [mTracker set:[GAIFields customMetricForIndex:[idx integerValue]] value:value];
            }
            if([key.lowercaseString isEqual:@"uid"]){ [mTracker set:kGAIUserId  value:value]; }
            if([key.lowercaseString isEqual:@"title"]){ [mTracker set:kGAIScreenName value:value]; }
            if([key.lowercaseString isEqual:@"camp_url"]){
                NSString *url = [(NSURL *) value absoluteString] ;
                [ecommerceBuilder setCampaignParametersFromUrl:url];
            }
            if([key.lowercaseString isEqual:@"cu"]){ [mTracker set:kGAICurrencyCode value:value]; }
            if([key.lowercaseString isEqual:@"category"]){ category = value; }
            if([key.lowercaseString isEqual:@"action"]){ action = value; }
            if([key.lowercaseString isEqual:@"label"]){ label = value; }
            if([key.lowercaseString isEqual:@"value"]){ event_value = value; }
            if([key.lowercaseString isEqual:@"ni"] && [[GAInfo valueForKey:key]  isEqual:@"1"]){
                [ecommerceBuilder set:@"1" forKey:kGAINonInteraction];
            }
        }
    }
    ecommerceBuilder = [GAIDictionaryBuilder createEventWithCategory:category action:action label:label value:[event_value intValue] != nil ?@([event_value intValue]): nil  ];
    //제품클릭 단계
    
    if([EcommerceStep.lowercaseString isEqual:@"impression"]){
        NSString *productActionList = GAAction[@"af_list"];
        for(NSString *keys in GAProduct){
            [GAProduct[keys] setObject:productActionList forKey:@"prlist"];
        }
    }
    
    if([EcommerceStep.lowercaseString isEqual:@"click"]){
        GAIEcommerceProductAction *pa = [GAIEcommerceProductAction new];
        [pa setAction:kGAIPAClick];
        pa = GA_ActionField(GAAction, pa);
        [ecommerceBuilder setProductAction:pa];
    }
    //디테일단계
    if([EcommerceStep.lowercaseString isEqual:@"detail"]){
        GAIEcommerceProductAction *pa = [GAIEcommerceProductAction new];
        [pa setAction:kGAIPADetail];
        pa = GA_ActionField(GAAction, pa);
        [ecommerceBuilder setProductAction:pa];
    }
    //장바구니추가 단계
    if([EcommerceStep.lowercaseString isEqual:@"add"]){
        GAIEcommerceProductAction *pa = [GAIEcommerceProductAction new];
        [pa setAction:kGAIPAAdd];
        pa = GA_ActionField(GAAction, pa);
        [ecommerceBuilder setProductAction:pa];
    }
    //장바구니삭제 단계
    if([EcommerceStep.lowercaseString isEqual:@"remove"]){
        GAIEcommerceProductAction *pa = [GAIEcommerceProductAction new];
        [pa setAction:kGAIPARemove];
        pa = GA_ActionField(GAAction, pa);
        [ecommerceBuilder setProductAction:pa];
    }
    //체크아웃 단계
    if([EcommerceStep.lowercaseString isEqual:@"checkout"]){
        GAIEcommerceProductAction *pa = [GAIEcommerceProductAction new];
        [pa setAction:kGAIPACheckout];
        pa = GA_ActionField(GAAction, pa);
        [ecommerceBuilder setProductAction:pa];
    }
    //결제 단계
    if([EcommerceStep.lowercaseString isEqual:@"purchase"]){
        GAIEcommerceProductAction *pa = [GAIEcommerceProductAction new];
        [pa setAction:kGAIPAPurchase];
        pa = GA_ActionField(GAAction, pa);
        [ecommerceBuilder setProductAction:pa];
    }
    //리펀드 단계
    if([EcommerceStep.lowercaseString isEqual:@"refund"]){
        GAIEcommerceProductAction *pa = [GAIEcommerceProductAction new];
        [pa setAction:kGAIPARefund];
        pa = GA_ActionField(GAAction, pa);
        [ecommerceBuilder setProductAction:pa];
    }
    if([EcommerceStep.lowercaseString containsString:@"promotion"]){
        GAIEcommercePromotion *promotion = [[GAIEcommercePromotion alloc]init];
        for(NSString *key in GAInfo){
            NSString *value = [GAInfo valueForKey:key];
            if(value != nil && [value length] >0 ){
                if([key.lowercaseString isEqual:@"promo_id"]){ [promotion setId:value]; }
                if([key.lowercaseString isEqual:@"promo_nm"]){ [promotion setName:value]; }
                if([key.lowercaseString isEqual:@"promo_cr"]){ [promotion setCreative:value]; }
                if([key.lowercaseString isEqual:@"promo_ps"]){ [promotion setPosition:value]; }
            }
        }
        if([EcommerceStep.lowercaseString isEqual:@"promotionclick"]){
            [ecommerceBuilder set:kGAIPromotionClick forKey:kGAIPromotionAction];
        }
        [ecommerceBuilder addPromotion:promotion];
    }else{
        ecommerceBuilder = GA_Product(EcommerceStep, GAProduct, ecommerceBuilder);
    }
    [mTracker send:[ecommerceBuilder build]];
    [mTracker set:kGAIScreenName value:nil];
    [mTracker set:kGAIUserId value:nil];
    GAData_Nilset(GAInfo);
    return true;
}

