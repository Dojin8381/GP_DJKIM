//
//  ViewController.h
//  REAL_UIWEB
//
//  Created by Goldenplanet on 06/08/2019.
//  Copyright © 2019 Goldenplanet. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
#import "AppDelegate.h"
#import "GoogleAnalyticsBuilder.h"
@interface ViewController : UIViewController



@end

