//
//  ViewController.m
//  REAL_UIWEB
//
//  Created by Goldenplanet on 06/08/2019.
//  Copyright © 2019 Goldenplanet. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    UIWebView *REAL_WEB = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, 400, 900)];
    UIWebView *webView = [[UIWebView alloc] init];
    NSString *suffixUA = @"/GA_iOS_UI";
    NSString *defaultUA = [webView stringByEvaluatingJavaScriptFromString:@"navigator.userAgent"];
    NSString * finalUA = [defaultUA stringByAppendingString:suffixUA];
    
      
    NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:finalUA, @"UserAgent", nil];
    [[NSUserDefaults standardUserDefaults] registerDefaults:dictionary];
    
    NSString *urlString = @"http://211.49.99.88:8011/alphalab/djkim";
    NSURL *url = [NSURL URLWithString:urlString];
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url];
    REAL_WEB.delegate = self;
    [REAL_WEB loadRequest:urlRequest];
    [self.view addSubview:REAL_WEB];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    NSString *requestString = [[request URL] absoluteString];
    if([[[request URL] absoluteString] hasPrefix:@"jscall://"] == true){
    NSArray *components = [requestString componentsSeparatedByString:@"://"];
        NSString *documentLocation = [[[[request URL] absoluteString] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding] stringByReplacingOccurrencesOfString:@"\\" withString:@""] ;
    NSString *functionName = [components objectAtIndex:1];
        requestString = [documentLocation stringByReplacingOccurrencesOfString:@"jscall://" withString:@""];
        NSError* error;
        NSDictionary* json = [NSJSONSerialization JSONObjectWithData:[requestString dataUsingEncoding:NSUTF8StringEncoding] options:kNilOptions error:&error];
        id<GAITracker> mTracker = [[GAI sharedInstance] defaultTracker]; // 개발서버와 운영서버에 맞는 추적코드를 입력합니다
        //이벤트
        NSString *sType;
        NSString *productList;
        GAIDictionaryBuilder *Event_Builder;
        if( [json objectForKey:@"type"] != nil ){ sType = [json objectForKey:@"type"]; }
        
        if([json objectForKey: @"userID"] != nil ){ [mTracker set:kGAIUserId value:[json objectForKey:@"userID"]]; }
        //맞춤측정기준
        NSObject *dimension= [json objectForKey:@"dimension"];
        if(dimension != nil){
            for(id key in dimension){
                NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"[^0-9]" options:NSRegularExpressionCaseInsensitive error:&error];
                NSString *idx = [regex stringByReplacingMatchesInString:key options:0 range:NSMakeRange(0, [key length]) withTemplate:@""];
                [mTracker set:[GAIFields customDimensionForIndex:[idx integerValue]] value:[dimension valueForKey:key]];
            }
        }
        //Metric
        NSObject *metric=[json objectForKey:@"metric"];
        if(metric != nil){
            for(id key in metric){
                NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"[^0-9]" options:NSRegularExpressionCaseInsensitive error:&error];
                NSString *idx = [regex stringByReplacingMatchesInString:key options:0 range:NSMakeRange(0, [key length]) withTemplate:@""];
                [mTracker set: [GAIFields customMetricForIndex:[idx integerValue]] value: [[metric valueForKey:key] stringValue]];
            }
        }
        [mTracker set:[GAIFields customDimensionForIndex:1] value:[mTracker get:kGAIClientId]]; //cilent ID 필요시 주석해제
        if( [json objectForKey:@"title"] != nil){ [mTracker set:kGAIScreenName value:[json objectForKey:@"title"]]; }
        if( [sType isEqualToString:@"P"] == true){
            [mTracker set:kGAIHitType value:@"screenview"];
        }
        else{
            //이벤트
            NSString *event_category = nil;
            NSString *event_action = nil;
            NSString *event_label = nil;
            if( [json objectForKey:@"category"] != nil){ event_category = [json objectForKey:@"category"]; }
            if( [json objectForKey:@"action"] != nil){ event_action = [json objectForKey:@"action"]; }
            if( [json objectForKey:@"label"] != nil){ event_label = [json objectForKey:@"label"]; }
            [mTracker set:kGAIHitType value:@"event"];
            Event_Builder = [GAIDictionaryBuilder createEventWithCategory:event_category action:event_action label:event_label value:nil];
            if([json objectForKey:@"nonInteraction"] != nil && [[json objectForKey:@"nonInteraction"]  isEqual: @"1"] )
                [Event_Builder set:@"1" forKey:kGAINonInteraction];
        }
        //전자상거래
        if( [json objectForKey:@"ecommerce"] != nil){
            // 데이터
            NSDictionary *promotion_data;
            GAIEcommercePromotion *promotion = [[GAIEcommercePromotion alloc]init];
            NSMutableDictionary *ecommerce_dict = [json objectForKey:@"ecommerce"];
            for(NSString *key in ecommerce_dict){
                GAIEcommerceProductAction *action = [GAIEcommerceProductAction new];
                NSString *Ecommerce_step = key;
                if([key.lowercaseString containsString:@"promoview"] || [key.lowercaseString containsString:@"promoclick"]){
                    NSDictionary *promotion_dict = [ecommerce_dict valueForKey:key];
                    for(NSString *key in promotion_dict){
                        if([key.lowercaseString containsString:@"promotions"]){
                            promotion_data = [promotion_dict valueForKey:key];
                            Event_Builder = GAData_Promotion(promotion_data, Ecommerce_step, Event_Builder);
                            [Event_Builder addPromotion:promotion];
                        }
                    }
                }
                if([key.lowercaseString containsString:@"currencycode"]){
                    [mTracker set:kGAICurrencyCode value:[ecommerce_dict valueForKey:key]];
                } else {
                    NSMutableDictionary *ecommerce_info = [ecommerce_dict valueForKey:key];
                    if([key.lowercaseString containsString:@"impressions"]){
                        productList = [[ecommerce_info valueForKey:@"actionField"]valueForKey:@"list"];;
                    }
                    for(NSString *key in ecommerce_info){
                        if([key.lowercaseString containsString:@"products"] ){
                            NSDictionary *product_dict = [ecommerce_info valueForKey:key];
                            Event_Builder = GAData_Products(product_dict,Ecommerce_step,productList,Event_Builder);
                        }
                        if([key.lowercaseString containsString:@"actionfield"] ){
                            NSMutableDictionary *actionField = [ecommerce_info valueForKey:key];
                            action = GAData_Actionfield(actionField, action);
                            [Event_Builder setProductAction:action];
                        }
                    }
                }
                if([key.lowercaseString containsString:@"click"]){ [action setAction:kGAIPAClick]; }
                if([key.lowercaseString containsString:@"detail"]){ [action setAction:kGAIPADetail]; }
                if([key.lowercaseString containsString:@"add"]){ [action setAction:kGAIPAAdd]; }
                if([key.lowercaseString containsString:@"checkout"]){ [action setAction:kGAIPACheckout]; }
                if([key.lowercaseString containsString:@"purchase"]){ [action setAction:kGAIPAPurchase]; }
                if([key.lowercaseString containsString:@"remove"]){ [action setAction:kGAIPARemove]; }
                if([key.lowercaseString containsString:@"refund"]){ [action setAction:kGAIPARefund]; }
                
                
            }
        }
        [mTracker send:[Event_Builder build]];
        GAData_Nilset(dimension);
        GAData_Nilset(metric);
        return NO;
    }
    return YES;
}
GAIDictionaryBuilder *GAData_Promotion(NSDictionary *promotion_dict, NSString *EcommerceStep, GAIDictionaryBuilder *ecommerceBuiler){
    NSMutableArray  *rArray = promotion_dict;
    for(int i=0; i<rArray.count ; i++){
        GAIEcommercePromotion *promotion = [[GAIEcommercePromotion alloc]init];
        NSDictionary *dict = [rArray objectAtIndex:i];
        for(NSString *key in dict){
            NSString *value = [dict valueForKey:key];
            if( [key.lowercaseString containsString:@"id"]){ [promotion setId:value]; }
            if( [key.lowercaseString containsString:@"name"]){ [promotion setName:value]; }
            if( [key.lowercaseString containsString:@"creative"]){ [promotion setCreative:value]; }
            if( [key.lowercaseString containsString:@"position"]){ [promotion setPosition:value]; }
        }
        if(![EcommerceStep  isEqual: @"promoclick"]){
            [ecommerceBuiler addPromotion:promotion];
        }else{
            [ecommerceBuiler set:kGAIPromotionClick forKey:kGAIPromotionAction];
            [ecommerceBuiler addPromotion:promotion];
        }
    }
    return ecommerceBuiler;
}

GAIDictionaryBuilder *GAData_Products(NSDictionary *product_dict, NSString *EcommerceStep, NSString *productList,GAIDictionaryBuilder *ecommerceBuiler){
    NSString *error;
    NSMutableArray  *rArray = product_dict;
    for(int i=0; i<rArray.count ; i++)
    {
        GAIEcommerceProduct *products = [[GAIEcommerceProduct alloc]init];
        NSDictionary *dict = [rArray objectAtIndex:i];
        for(NSString *key in dict){
            NSString *value = [dict valueForKey:key];
            if( [key.lowercaseString containsString:@"id"]){ [products setId:value]; }
            if( [key.lowercaseString containsString:@"name"]){ [products setName:value]; }
            if( [key.lowercaseString containsString:@"brand"]){ [products setBrand:value]; }
            if( [key.lowercaseString containsString:@"category"]){ [products setCategory:value]; }
            if( [key.lowercaseString containsString:@"price"]){ [products setPrice:@([value intValue])]; }
            if( [key.lowercaseString containsString:@"quantity"]){ [products setQuantity:@([value intValue])]; }
            if( [key.lowercaseString containsString:@"variant"]){ [products setVariant:value]; }
            if( [key.lowercaseString containsString:@"coupon"]){ [products setCouponCode:value]; }
            if( [key.lowercaseString containsString:@"position"]){ [products setPosition:@([value intValue])]; }
            if([key.lowercaseString containsString:@"dimension"]){
                NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"[^0-9]" options:NSRegularExpressionCaseInsensitive error:&error];
                NSString *idx = [regex stringByReplacingMatchesInString:key options:0 range:NSMakeRange(0, [key length]) withTemplate:@""];
                [products setCustomDimension:[idx integerValue] value:[dict valueForKey:key]];
            }
            if([key.lowercaseString containsString:@"metric"]){
                NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"[^0-9]" options:NSRegularExpressionCaseInsensitive error:&error];
                NSString *idx = [regex stringByReplacingMatchesInString:key options:0 range:NSMakeRange(0, [key length]) withTemplate:@""];
                [products setCustomMetric:[idx integerValue] value:[dict valueForKey:key]];
            }
        }
        if(![EcommerceStep  isEqual: @"impressions"]){
            [ecommerceBuiler addProduct:products];
        }else{
            [ecommerceBuiler addProductImpression:products impressionList:productList impressionSource:@"impressionSource"];
        }
    }
    return ecommerceBuiler;
}

GAIEcommerceProductAction *GAData_Actionfield(NSMutableDictionary *actionField_dict, GAIEcommerceProductAction *productAction){
    for(NSString *key in actionField_dict){
        if([[key lowercaseString]containsString:@"id"]){
            [productAction setTransactionId:[actionField_dict valueForKey:key]];
        }
        if([[key lowercaseString]containsString:@"revenue"]){
            [productAction setRevenue:@([[actionField_dict valueForKey:key] intValue])];
        }
        if([[key lowercaseString]containsString:@"tax"]){
            [productAction setTax:@([[actionField_dict valueForKey:key] intValue])];
        }
        if([[key lowercaseString]containsString:@"shipping"]){
            [productAction setShipping:@([[actionField_dict valueForKey:key] intValue])];
        }
        if([[key lowercaseString]containsString:@"coupon"]){
            [productAction setCouponCode:[actionField_dict valueForKey:key]];
        }
        if([[key lowercaseString]containsString:@"affiliation"]){
            [productAction setAffiliation:[actionField_dict valueForKey:key]];
        }
        if([[key lowercaseString]containsString:@"list"]){
            [productAction setProductActionList:[actionField_dict valueForKey:key]];
        }
        if([[key lowercaseString]containsString:@"step"]){
            [productAction setCheckoutStep:@([[actionField_dict valueForKey:key] intValue])];
        }
        if([[key lowercaseString]containsString:@"option"]){
            [productAction setCheckoutOption:[actionField_dict valueForKey:key]];
        }
    }
    return productAction;
}
@end
