//
//  AppDelegate.h
//  REAL_UIWEB
//
//  Created by Goldenplanet on 06/08/2019.
//  Copyright © 2019 Goldenplanet. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import <Google/Analytics.h>
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (readonly, strong) NSPersistentContainer *persistentContainer;

- (void)saveContext;


@end

