//
//  GoogleAnalyticsBuilder.h
//  REAL_UIWEB
//
//  Created by Goldenplanet on 06/08/2019.
//  Copyright © 2019 Goldenplanet. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AppDelegate.h"
#import "ViewController.h"

typedef enum {
    Dimension1, Dimension2, Dimension3,Dimension4, Dimension5, Dimension6, Dimension7, Dimension8, Dimension9,
    Dimension10, Dimension11, Dimension12,Dimension13, Dimension14, Dimension15, Dimension16, Dimension17,
    Dimension18,Dimension19, Dimension20,Dimension21, Dimension22,Dimension23, Dimension24,Dimension25,
    Dimension26,Dimension27, Dimension28,Dimension29, Dimension30,Dimension31, Dimension32,Dimension33,
    Dimension34,Dimension35, Dimension36,Dimension37, Dimension38,Dimension39, Dimension40,Dimension41,
    Dimension42,Dimension43, Dimension44,Dimension45, Dimension46,Dimension47, Dimension48,Dimension49,
    Dimension50,
    Metric1, Metric2, Metric3, Metric4, Metric5, Metric6, Metric7, Metric8, Metric9, Metric10,
    Metric11, Metric12, Metric13, Metric14, Metric15, Metric16, Metric17, Metric18, Metric19,
    Metric20, Metric21, Metric22, Metric23, Metric24, Metric25, Metric26, Metric27, Metric28, Metric29,
    Metric30, Metric31, Metric32, Metric33, Metric34, Metric35, Metric36, Metric37, Metric38, Metric39,
    Metric40, Metric41, Metric42, Metric43, Metric44, Metric45, Metric46, Metric47, Metric48, Metric49,
    Metric50
};
typedef enum {
    UserID,
    CampaignUrl,
    Title,
    EventCategory,
    EventAction,
    EventLabel,
    EventValue,
    NonInteraction,
    PromotionID,
    PromotionName,
    PromotionCreative,
    PromotionPosition,
    CurrencyCode
};
typedef enum {
    Impression,
    Detail,
    Click,
    Add,
    Remove,
    Checkout,
    Purchase,
    Refund,
    PromotionImpression,
    PromotionClick
};
typedef enum {
    ProductID,
    ProductName,
    ProductBrand,
    ProductCategory,
    ProductVariant,
    ProductPrice,
    ProductQuantity,
    ProductCouponCode,
    ProductPosition,
    ImpressionList,
    ProductDimension1, ProductDimension2, ProductDimension3, ProductDimension4, ProductDimension5,
    ProductDimension6, ProductDimension7, ProductDimension8, ProductDimension9, ProductDimension10,
    ProductDimension11, ProductDimension12, ProductDimension13, ProductDimension14, ProductDimension15,
    ProductDimension16, ProductDimension17, ProductDimension18, ProductDimension19, ProductDimension20,
    ProductMetric1, ProductMetric2, ProductMetric3, ProductMetric4, ProductMetric5,
    ProductMetric6, ProductMetric7, ProductMetric8, ProductMetric9, ProductMetric10,
    ProductMetric11, ProductMetric12, ProductMetric13, ProductMetric14, ProductMetric15,
    ProductMetric16, ProductMetric17, ProductMetric18, ProductMetric19, ProductMetric20
};
typedef enum  {
    TransactionID,
    TransactionRevenue,
    TransactionTax,
    TransactionShipping,
    TransactionCouponCode,
    TransactionAffiliation,
    ProductActionList,
    CheckoutStep,
    CheckoutOptions
};
void *GADataSend_Screen(NSMutableDictionary *screen_Map);
void *GADataSend_Event(NSMutableDictionary *Event_dict);
void *GADataSend_Ecommerce(NSString *EcommerceStep, NSMutableDictionary *GAAction, NSMutableDictionary *GAProduct, NSMutableDictionary *GAEcommerce );
void *GAData_Nilset(NSMutableDictionary *dict);
NSString *GACustomKey(UIImageOrientation input) ;
NSString *GAHitKey(UIImageOrientation input);
NSString *GAEcommerceStepKey(UIImageOrientation input);
NSString *GAActionFieldKey(UIImageOrientation input);
NSString *GAProductKey(UIImageOrientation input);
@interface GoogleAnalyticsBuilder:NSObject
@end

